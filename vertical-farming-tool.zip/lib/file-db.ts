import { v4 as uuidv4 } from "uuid"

// Initialize users if none exist
const initializeUsers = () => {
  const storedUsers = localStorage.getItem("db_users.json")
  if (!storedUsers) {
    // Create default users
    const defaultUsers = [
      {
        id: "1",
        email: "demo@example.com",
        password: "password123", // In production, this would be hashed
        fullName: "Demo User",
        createdAt: new Date().toISOString(),
      },
      {
        id: "2",
        email: "test@example.com",
        password: "password123", // In production, this would be hashed
        fullName: "Test User",
        createdAt: new Date().toISOString(),
      },
    ]
    localStorage.setItem("db_users.json", JSON.stringify(defaultUsers))
  }
}

// Call this function when the module loads
if (typeof window !== "undefined") {
  initializeUsers()
}

// Types
export interface User {
  id: string
  email: string
  password: string // In production, this should be hashed
  fullName?: string
  createdAt: string
}

export interface FarmConfig {
  id: string
  userId: string
  systemType: "vertical-rack" | "tower" | "a-frame"
  farmSize: {
    width: number
    height: number
    depth: number
  }
  createdAt: string
  updatedAt: string
}

export interface PlantModule {
  id: string
  userId: string
  type: string
  plantedDate: string
  health: "excellent" | "good" | "fair" | "poor"
  notes: Array<{ text: string; date: string }>
  position: { x: number; y: number; z: number }
  tower?: number
  level?: number
  frame?: number
  side?: "left" | "right"
  createdAt: string
  updatedAt: string
}

export interface LightingSystem {
  id: string
  userId: string
  position: { x: number; y: number; z: number }
  intensity: number
  coverage: number
  type: "LED" | "Fluorescent" | "Incandescent" | "HPS" | "CMH" | "T5" | "CFL"
  tower?: number
  frame?: number
  createdAt: string
  updatedAt: string
}

export interface IrrigationPipe {
  id: string
  userId: string
  fromPosition: { x: number; y: number; z: number }
  toPosition: { x: number; y: number; z: number }
  type: "main" | "branch"
  fromTower?: number
  toTower?: number
  fromLevel?: number
  toLevel?: number
  fromFrame?: number
  toFrame?: number
  fromSide?: "left" | "right"
  toSide?: "left" | "right"
  createdAt: string
  updatedAt: string
}

// File operations
async function readFile<T>(filename: string): Promise<T[]> {
  try {
    const response = await fetch(`/data/${filename}`)
    if (!response.ok) return []
    return await response.json()
  } catch (error) {
    console.error(`Error reading ${filename}:`, error)
    return []
  }
}

async function writeFile<T>(filename: string, data: T[]): Promise<void> {
  try {
    // In a real implementation, you'd need a server endpoint to handle file writes
    // For now, we'll store in localStorage as a fallback
    localStorage.setItem(`db_${filename}`, JSON.stringify(data))
  } catch (error) {
    console.error(`Error writing ${filename}:`, error)
  }
}

// Database operations
export class FileDatabase {
  // Users
  static async getUsers(): Promise<User[]> {
    const stored = localStorage.getItem("db_users.json")
    return stored ? JSON.parse(stored) : []
  }

  static async createUser(userData: Omit<User, "id" | "createdAt">): Promise<User> {
    const users = await this.getUsers()
    const user: User = {
      ...userData,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    }
    users.push(user)
    await writeFile("users.json", users)
    return user
  }

  static async getUserByEmail(email: string): Promise<User | null> {
    const users = await this.getUsers()
    return users.find((user) => user.email === email) || null
  }

  static async getUserById(id: string): Promise<User | null> {
    const users = await this.getUsers()
    return users.find((user) => user.id === id) || null
  }

  // Farm Configs
  static async getFarmConfig(userId: string): Promise<FarmConfig | null> {
    const stored = localStorage.getItem("db_farm-configs.json")
    const configs: FarmConfig[] = stored ? JSON.parse(stored) : []
    return configs.find((config) => config.userId === userId) || null
  }

  static async saveFarmConfig(config: Omit<FarmConfig, "id" | "createdAt" | "updatedAt">): Promise<FarmConfig> {
    const stored = localStorage.getItem("db_farm-configs.json")
    const configs: FarmConfig[] = stored ? JSON.parse(stored) : []

    const existingIndex = configs.findIndex((c) => c.userId === config.userId)
    const now = new Date().toISOString()

    if (existingIndex >= 0) {
      configs[existingIndex] = {
        ...configs[existingIndex],
        ...config,
        updatedAt: now,
      }
      await writeFile("farm-configs.json", configs)
      return configs[existingIndex]
    } else {
      const newConfig: FarmConfig = {
        ...config,
        id: uuidv4(),
        createdAt: now,
        updatedAt: now,
      }
      configs.push(newConfig)
      await writeFile("farm-configs.json", configs)
      return newConfig
    }
  }

  // Plant Modules
  static async getPlantModules(userId: string): Promise<PlantModule[]> {
    const stored = localStorage.getItem("db_plant-modules.json")
    const modules: PlantModule[] = stored ? JSON.parse(stored) : []
    return modules.filter((module) => module.userId === userId)
  }

  static async savePlantModule(module: Omit<PlantModule, "createdAt" | "updatedAt">): Promise<PlantModule> {
    const stored = localStorage.getItem("db_plant-modules.json")
    const modules: PlantModule[] = stored ? JSON.parse(stored) : []

    const existingIndex = modules.findIndex((m) => m.id === module.id)
    const now = new Date().toISOString()

    if (existingIndex >= 0) {
      modules[existingIndex] = {
        ...module,
        updatedAt: now,
        createdAt: modules[existingIndex].createdAt,
      }
    } else {
      modules.push({
        ...module,
        createdAt: now,
        updatedAt: now,
      })
    }

    await writeFile("plant-modules.json", modules)
    return modules.find((m) => m.id === module.id)!
  }

  static async deletePlantModule(userId: string, moduleId: string): Promise<void> {
    const stored = localStorage.getItem("db_plant-modules.json")
    const modules: PlantModule[] = stored ? JSON.parse(stored) : []
    const filtered = modules.filter((m) => !(m.id === moduleId && m.userId === userId))
    await writeFile("plant-modules.json", filtered)
  }

  // Lighting Systems
  static async getLightingSystems(userId: string): Promise<LightingSystem[]> {
    const stored = localStorage.getItem("db_lighting-systems.json")
    const systems: LightingSystem[] = stored ? JSON.parse(stored) : []
    return systems.filter((system) => system.userId === userId)
  }

  static async saveLightingSystem(system: Omit<LightingSystem, "createdAt" | "updatedAt">): Promise<LightingSystem> {
    const stored = localStorage.getItem("db_lighting-systems.json")
    const systems: LightingSystem[] = stored ? JSON.parse(stored) : []

    const existingIndex = systems.findIndex((s) => s.id === system.id)
    const now = new Date().toISOString()

    if (existingIndex >= 0) {
      systems[existingIndex] = {
        ...system,
        updatedAt: now,
        createdAt: systems[existingIndex].createdAt,
      }
    } else {
      systems.push({
        ...system,
        createdAt: now,
        updatedAt: now,
      })
    }

    await writeFile("lighting-systems.json", systems)
    return systems.find((s) => s.id === system.id)!
  }

  static async deleteLightingSystem(userId: string, systemId: string): Promise<void> {
    const stored = localStorage.getItem("db_lighting-systems.json")
    const systems: LightingSystem[] = stored ? JSON.parse(stored) : []
    const filtered = systems.filter((s) => !(s.id === systemId && s.userId === userId))
    await writeFile("lighting-systems.json", filtered)
  }

  // Irrigation Pipes
  static async getIrrigationPipes(userId: string): Promise<IrrigationPipe[]> {
    const stored = localStorage.getItem("db_irrigation-pipes.json")
    const pipes: IrrigationPipe[] = stored ? JSON.parse(stored) : []
    return pipes.filter((pipe) => pipe.userId === userId)
  }

  static async saveIrrigationPipe(pipe: Omit<IrrigationPipe, "createdAt" | "updatedAt">): Promise<IrrigationPipe> {
    const stored = localStorage.getItem("db_irrigation-pipes.json")
    const pipes: IrrigationPipe[] = stored ? JSON.parse(stored) : []

    const existingIndex = pipes.findIndex((p) => p.id === pipe.id)
    const now = new Date().toISOString()

    if (existingIndex >= 0) {
      pipes[existingIndex] = {
        ...pipe,
        updatedAt: now,
        createdAt: pipes[existingIndex].createdAt,
      }
    } else {
      pipes.push({
        ...pipe,
        createdAt: now,
        updatedAt: now,
      })
    }

    await writeFile("irrigation-pipes.json", pipes)
    return pipes.find((p) => p.id === pipe.id)!
  }

  static async deleteIrrigationPipe(userId: string, pipeId: string): Promise<void> {
    const stored = localStorage.getItem("db_irrigation-pipes.json")
    const pipes: IrrigationPipe[] = stored ? JSON.parse(stored) : []
    const filtered = pipes.filter((p) => !(p.id === pipeId && p.userId === userId))
    await writeFile("irrigation-pipes.json", filtered)
  }
}
