import { supabase } from "./supabase"
import type {
  PlantModule,
  LightingSystem,
  IrrigationPipe,
  FarmSize,
  FarmingSystemType,
} from "@/app/contexts/farm-context"
import type { EnvironmentalData, EnvironmentalSettings, HistoricalData } from "@/app/contexts/environment-context"
import type { GrowthData } from "@/app/contexts/growth-context"
import { FileDatabase, type FarmConfig } from "./file-db"

// Farm data service
export const farmService = {
  // Save farm configuration
  async saveFarmConfig(userId: string, systemType: FarmingSystemType, farmSize: FarmSize) {
    try {
      const { data, error } = await supabase
        .from("farm_configs")
        .upsert({
          user_id: userId,
          system_type: systemType,
          farm_size: farmSize,
          updated_at: new Date().toISOString(),
        })
        .select()

      if (error) throw error
      return data
    } catch (error) {
      console.error("Error saving farm config:", error)
      throw error
    }
  },

  // Get farm configuration
  async getFarmConfig(userId: string) {
    try {
      const { data, error } = await supabase.from("farm_configs").select("*").eq("user_id", userId).single()

      if (error && error.code !== "PGRST116") throw error // PGRST116 is "no rows returned"
      return data
    } catch (error) {
      console.error("Error getting farm config:", error)
      throw error
    }
  },

  // Save plant modules
  async savePlantModules(userId: string, modules: PlantModule[]) {
    try {
      // First, get existing modules to determine which to update/delete
      const { data: existingModules, error: fetchError } = await supabase
        .from("plant_modules")
        .select("id")
        .eq("user_id", userId)

      if (fetchError) throw fetchError

      // Prepare data for upsert (update or insert)
      const modulesToUpsert = modules.map((module) => ({
        ...module,
        user_id: userId,
        updated_at: new Date().toISOString(),
      }))

      // Upsert modules
      if (modulesToUpsert.length > 0) {
        const { error: upsertError } = await supabase.from("plant_modules").upsert(modulesToUpsert)

        if (upsertError) throw upsertError
      }

      // Delete modules that no longer exist
      if (existingModules) {
        const currentModuleIds = modules.map((m) => m.id)
        const modulesToDelete = existingModules.filter((m) => !currentModuleIds.includes(m.id)).map((m) => m.id)

        if (modulesToDelete.length > 0) {
          const { error: deleteError } = await supabase.from("plant_modules").delete().in("id", modulesToDelete)

          if (deleteError) throw deleteError
        }
      }

      return true
    } catch (error) {
      console.error("Error saving plant modules:", error)
      throw error
    }
  },

  // Get plant modules
  async getPlantModules(userId: string) {
    try {
      const { data, error } = await supabase.from("plant_modules").select("*").eq("user_id", userId)

      if (error) throw error
      return data || []
    } catch (error) {
      console.error("Error getting plant modules:", error)
      throw error
    }
  },

  // Save lighting systems
  async saveLightingSystems(userId: string, lighting: LightingSystem[]) {
    try {
      // First, get existing lighting to determine which to update/delete
      const { data: existingLighting, error: fetchError } = await supabase
        .from("lighting_systems")
        .select("id")
        .eq("user_id", userId)

      if (fetchError) throw fetchError

      // Prepare data for upsert
      const lightingToUpsert = lighting.map((light) => ({
        ...light,
        user_id: userId,
        updated_at: new Date().toISOString(),
      }))

      // Upsert lighting
      if (lightingToUpsert.length > 0) {
        const { error: upsertError } = await supabase.from("lighting_systems").upsert(lightingToUpsert)

        if (upsertError) throw upsertError
      }

      // Delete lighting that no longer exists
      if (existingLighting) {
        const currentLightingIds = lighting.map((l) => l.id)
        const lightingToDelete = existingLighting.filter((l) => !currentLightingIds.includes(l.id)).map((l) => l.id)

        if (lightingToDelete.length > 0) {
          const { error: deleteError } = await supabase.from("lighting_systems").delete().in("id", lightingToDelete)

          if (deleteError) throw deleteError
        }
      }

      return true
    } catch (error) {
      console.error("Error saving lighting systems:", error)
      throw error
    }
  },

  // Get lighting systems
  async getLightingSystems(userId: string) {
    try {
      const { data, error } = await supabase.from("lighting_systems").select("*").eq("user_id", userId)

      if (error) throw error
      return data || []
    } catch (error) {
      console.error("Error getting lighting systems:", error)
      throw error
    }
  },

  // Save irrigation pipes
  async saveIrrigationPipes(userId: string, irrigation: IrrigationPipe[]) {
    try {
      // First, get existing pipes to determine which to update/delete
      const { data: existingPipes, error: fetchError } = await supabase
        .from("irrigation_pipes")
        .select("id")
        .eq("user_id", userId)

      if (fetchError) throw fetchError

      // Prepare data for upsert
      const pipesToUpsert = irrigation.map((pipe) => ({
        ...pipe,
        user_id: userId,
        updated_at: new Date().toISOString(),
      }))

      // Upsert pipes
      if (pipesToUpsert.length > 0) {
        const { error: upsertError } = await supabase.from("irrigation_pipes").upsert(pipesToUpsert)

        if (upsertError) throw upsertError
      }

      // Delete pipes that no longer exist
      if (existingPipes) {
        const currentPipeIds = irrigation.map((p) => p.id)
        const pipesToDelete = existingPipes.filter((p) => !currentPipeIds.includes(p.id)).map((p) => p.id)

        if (pipesToDelete.length > 0) {
          const { error: deleteError } = await supabase.from("irrigation_pipes").delete().in("id", pipesToDelete)

          if (deleteError) throw deleteError
        }
      }

      return true
    } catch (error) {
      console.error("Error saving irrigation pipes:", error)
      throw error
    }
  },

  // Get irrigation pipes
  async getIrrigationPipes(userId: string) {
    try {
      const { data, error } = await supabase.from("irrigation_pipes").select("*").eq("user_id", userId)

      if (error) throw error
      return data || []
    } catch (error) {
      console.error("Error getting irrigation pipes:", error)
      throw error
    }
  },
}

// Environment data service
export const environmentService = {
  // Save environmental settings
  async saveEnvironmentalSettings(userId: string, settings: EnvironmentalSettings) {
    try {
      const { data, error } = await supabase
        .from("environmental_settings")
        .upsert({
          user_id: userId,
          settings,
          updated_at: new Date().toISOString(),
        })
        .select()

      if (error) throw error
      return data
    } catch (error) {
      console.error("Error saving environmental settings:", error)
      throw error
    }
  },

  // Get environmental settings
  async getEnvironmentalSettings(userId: string) {
    try {
      const { data, error } = await supabase
        .from("environmental_settings")
        .select("settings")
        .eq("user_id", userId)
        .single()

      if (error && error.code !== "PGRST116") throw error
      return data?.settings
    } catch (error) {
      console.error("Error getting environmental settings:", error)
      throw error
    }
  },

  // Save current environmental data
  async saveEnvironmentalData(userId: string, data: EnvironmentalData) {
    try {
      const { error } = await supabase.from("environmental_data").upsert({
        user_id: userId,
        data,
        timestamp: new Date().toISOString(),
      })

      if (error) throw error
      return true
    } catch (error) {
      console.error("Error saving environmental data:", error)
      throw error
    }
  },

  // Get latest environmental data
  async getLatestEnvironmentalData(userId: string) {
    try {
      const { data, error } = await supabase
        .from("environmental_data")
        .select("data")
        .eq("user_id", userId)
        .order("timestamp", { ascending: false })
        .limit(1)
        .single()

      if (error && error.code !== "PGRST116") throw error
      return data?.data
    } catch (error) {
      console.error("Error getting latest environmental data:", error)
      throw error
    }
  },

  // Save historical data
  async saveHistoricalData(userId: string, data: HistoricalData[]) {
    try {
      // Convert to database format
      const dbData = data.map((item) => ({
        user_id: userId,
        timestamp: item.timestamp,
        temperature: item.temperature,
        humidity: item.humidity,
        co2_level: item.co2Level,
      }))

      // Clear existing data first (to avoid duplicates)
      await supabase.from("historical_data").delete().eq("user_id", userId)

      // Insert new data
      const { error } = await supabase.from("historical_data").insert(dbData)

      if (error) throw error
      return true
    } catch (error) {
      console.error("Error saving historical data:", error)
      throw error
    }
  },

  // Get historical data
  async getHistoricalData(userId: string) {
    try {
      const { data, error } = await supabase
        .from("historical_data")
        .select("*")
        .eq("user_id", userId)
        .order("timestamp", { ascending: true })

      if (error) throw error

      // Convert to application format
      return (data || []).map((item) => ({
        timestamp: item.timestamp,
        temperature: item.temperature,
        humidity: item.humidity,
        co2Level: item.co2_level,
      }))
    } catch (error) {
      console.error("Error getting historical data:", error)
      throw error
    }
  },
}

// Growth data service
export const growthService = {
  // Save growth data
  async saveGrowthData(userId: string, growthData: GrowthData[]) {
    try {
      // First, get existing growth data to determine which to update/delete
      const { data: existingData, error: fetchError } = await supabase
        .from("growth_data")
        .select("id")
        .eq("user_id", userId)

      if (fetchError) throw fetchError

      // Prepare data for upsert
      const dataToUpsert = growthData.map((data) => ({
        id: data.moduleId, // Use moduleId as the primary key
        user_id: userId,
        module_id: data.moduleId,
        plant_type: data.plantType,
        measurements: data.measurements,
        updated_at: new Date().toISOString(),
      }))

      // Upsert growth data
      if (dataToUpsert.length > 0) {
        const { error: upsertError } = await supabase.from("growth_data").upsert(dataToUpsert)

        if (upsertError) throw upsertError
      }

      // Delete growth data that no longer exists
      if (existingData) {
        const currentDataIds = growthData.map((d) => d.moduleId)
        const dataToDelete = existingData.filter((d) => !currentDataIds.includes(d.id)).map((d) => d.id)

        if (dataToDelete.length > 0) {
          const { error: deleteError } = await supabase.from("growth_data").delete().in("id", dataToDelete)

          if (deleteError) throw deleteError
        }
      }

      return true
    } catch (error) {
      console.error("Error saving growth data:", error)
      throw error
    }
  },

  // Get growth data
  async getGrowthData(userId: string) {
    try {
      const { data, error } = await supabase.from("growth_data").select("*").eq("user_id", userId)

      if (error) throw error

      // Convert to application format
      return (data || []).map((item) => ({
        moduleId: item.module_id,
        plantType: item.plant_type,
        measurements: item.measurements,
      }))
    } catch (error) {
      console.error("Error getting growth data:", error)
      throw error
    }
  },
}

export class DatabaseService {
  // Farm Configuration
  static async getFarmConfig(userId: string): Promise<FarmConfig | null> {
    return await FileDatabase.getFarmConfig(userId)
  }

  static async saveFarmConfig(
    userId: string,
    config: {
      systemType: "vertical-rack" | "tower" | "a-frame"
      farmSize: { width: number; height: number; depth: number }
    },
  ): Promise<FarmConfig> {
    return await FileDatabase.saveFarmConfig({
      userId,
      ...config,
    })
  }

  // Plant Modules
  static async getPlantModules(userId: string): Promise<PlantModule[]> {
    return await FileDatabase.getPlantModules(userId)
  }

  static async savePlantModule(
    userId: string,
    module: Omit<PlantModule, "userId" | "createdAt" | "updatedAt">,
  ): Promise<PlantModule> {
    return await FileDatabase.savePlantModule({
      ...module,
      userId,
    })
  }

  static async deletePlantModule(userId: string, moduleId: string): Promise<void> {
    return await FileDatabase.deletePlantModule(userId, moduleId)
  }

  // Lighting Systems
  static async getLightingSystems(userId: string): Promise<LightingSystem[]> {
    return await FileDatabase.getLightingSystems(userId)
  }

  static async saveLightingSystem(
    userId: string,
    system: Omit<LightingSystem, "userId" | "createdAt" | "updatedAt">,
  ): Promise<LightingSystem> {
    return await FileDatabase.saveLightingSystem({
      ...system,
      userId,
    })
  }

  static async deleteLightingSystem(userId: string, systemId: string): Promise<void> {
    return await FileDatabase.deleteLightingSystem(userId, systemId)
  }

  // Irrigation Pipes
  static async getIrrigationPipes(userId: string): Promise<IrrigationPipe[]> {
    return await FileDatabase.getIrrigationPipes(userId)
  }

  static async saveIrrigationPipe(
    userId: string,
    pipe: Omit<IrrigationPipe, "userId" | "createdAt" | "updatedAt">,
  ): Promise<IrrigationPipe> {
    return await FileDatabase.saveIrrigationPipe({
      ...pipe,
      userId,
    })
  }

  static async deleteIrrigationPipe(userId: string, pipeId: string): Promise<void> {
    return await FileDatabase.deleteIrrigationPipe(userId, pipeId)
  }
}
