"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "./contexts/auth-context"
import { Loader2 } from "lucide-react"

export default function RootPage() {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading) {
      if (user) {
        // User is authenticated, redirect to dashboard
        router.replace("/dashboard")
      } else {
        // User is not authenticated, redirect to login
        router.replace("/login")
      }
    }
  }, [user, loading, router])

  // Show loading while determining where to redirect
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 flex items-center justify-center">
      <div className="text-center">
        <Loader2 className="h-12 w-12 animate-spin text-green-600 mx-auto" />
        <p className="mt-4 text-lg text-green-800">Loading AgriForce...</p>
      </div>
    </div>
  )
}
