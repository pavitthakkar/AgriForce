// Groq API constants
const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
const DEFAULT_MODEL = "llama3-8b-8192" // Using a different supported model

export async function POST(req: Request) {
  try {
    console.log("Chat API called")

    // Check if GROQ_API_KEY is available
    const apiKey = process.env.GROQ_API_KEY
    if (!apiKey) {
      console.error("GROQ_API_KEY not found in environment variables")
      return Response.json(
        {
          error: "API key not configured",
          details: "GROQ_API_KEY environment variable is missing",
        },
        { status: 500 },
      )
    }

    // Parse request
    const body = await req.json()
    const { message, farmContext } = body

    if (!message) {
      return Response.json(
        {
          error: "Message is required",
          details: "No message provided in request body",
        },
        { status: 400 },
      )
    }

    // Create system prompt with farm context
    const systemPrompt = `You are an expert vertical farming assistant. You have access to real-time data from the user's farm and should provide helpful, specific advice based on their current setup.

Current Farm Data:
- System Type: ${farmContext?.systemType || "Unknown"}
- Total Modules: ${farmContext?.totalModules || 0}
- Plant Types: ${farmContext?.plantTypes?.join(", ") || "None"}
- Health Distribution: ${
      farmContext?.healthStats
        ? Object.entries(farmContext.healthStats)
            .map(([health, count]) => `${health}: ${count}`)
            .join(", ")
        : "No data"
    }
- Current Temperature: ${farmContext?.currentEnvironment?.temperature?.toFixed(1) || "Unknown"}°C (Target: ${
      farmContext?.currentEnvironment?.targetTemperature || "Unknown"
    }°C)
- Current Humidity: ${farmContext?.currentEnvironment?.humidity?.toFixed(1) || "Unknown"}% (Target: ${
      farmContext?.currentEnvironment?.targetHumidity || "Unknown"
    }%)
- CO2 Level: ${farmContext?.currentEnvironment?.co2Level?.toFixed(0) || "Unknown"} ppm (Target: ${
      farmContext?.currentEnvironment?.targetCo2Level || "Unknown"
    } ppm)
- Water pH: ${farmContext?.currentEnvironment?.waterPh?.toFixed(1) || "Unknown"}
- Lighting: ${farmContext?.lighting?.totalUnits || 0} units, types: ${
      farmContext?.lighting?.types?.join(", ") || "None"
    }
- Irrigation: ${farmContext?.irrigation?.totalPipes || 0} pipes (${farmContext?.irrigation?.mainPipes || 0} main, ${
      farmContext?.irrigation?.branchPipes || 0
    } branch)

${
  farmContext?.unhealthyPlants?.length > 0
    ? `Plants Needing Attention:
${farmContext.unhealthyPlants
  .map((p) => `- ${p.type} at ${p.location}: ${p.health} health. Last note: ${p.lastNote}`)
  .join("\n")}`
    : "All plants are healthy!"
}

${
  farmContext?.recentNotes?.length > 0
    ? `Recent Plant Notes:
${farmContext.recentNotes
  .slice(0, 5)
  .map((n) => `- ${n.plant} (${n.date}): ${n.note}`)
  .join("\n")}`
    : "No recent notes."
}

Provide helpful, specific advice based on this data. Be concise but informative. Use emojis to make responses more engaging. Keep responses under 300 words.`

    console.log("Preparing Groq API request with model:", DEFAULT_MODEL)

    // Make direct request to the Groq API
    const groqResponse = await fetch(GROQ_API_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: DEFAULT_MODEL,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: message },
        ],
        temperature: 0.7,
        max_tokens: 500,
        top_p: 1,
        stream: false,
      }),
    })

    if (!groqResponse.ok) {
      const errorText = await groqResponse.text()
      console.error("Groq API error:", groqResponse.status, errorText)

      // Try to parse error as JSON for better error messages
      let errorDetails = errorText
      try {
        const errorJson = JSON.parse(errorText)
        errorDetails = errorJson.error?.message || errorText
      } catch {
        // Keep original error text if not JSON
      }

      return Response.json(
        {
          error: "Failed to get response from Groq API",
          details: `Status ${groqResponse.status}: ${errorDetails}`,
        },
        { status: 500 },
      )
    }

    // Parse the Groq response
    const groqData = await groqResponse.json()
    const responseContent = groqData.choices?.[0]?.message?.content || "Sorry, I couldn't generate a response."

    console.log("Groq API response received successfully")

    return Response.json({ response: responseContent })
  } catch (error) {
    console.error("Detailed error in chat API:", error)

    // More detailed error information
    const errorDetails =
      error instanceof Error
        ? {
            message: error.message,
            stack: error.stack,
            name: error.name,
          }
        : {
            message: "Unknown error occurred",
          }

    console.error("Error details:", errorDetails)

    return Response.json(
      {
        error: "Failed to get AI response",
        details: errorDetails.message,
        debug: process.env.NODE_ENV === "development" ? errorDetails : undefined,
      },
      { status: 500 },
    )
  }
}
