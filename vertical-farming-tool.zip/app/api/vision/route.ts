// Groq API constants for vision
const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
const VISION_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct" // Specific model for vision

export async function POST(req: Request) {
  try {
    console.log("Vision API called with model:", VISION_MODEL)

    // Check if GROQ_API_KEY is available
    const apiKey = process.env.GROQ_API_KEY
    if (!apiKey) {
      console.error("GROQ_API_KEY not found in environment variables")
      return Response.json(
        {
          error: "API key not configured",
          details: "GROQ_API_KEY environment variable is missing",
        },
        { status: 500 },
      )
    }

    // Parse request
    const body = await req.json()
    const { message, image } = body

    if (!message && !image) {
      return Response.json(
        {
          error: "Message or image is required",
          details: "No message or image provided in request body",
        },
        { status: 400 },
      )
    }

    // If no image provided, provide text-based agricultural guidance
    if (!image) {
      return Response.json({
        response: `🌱 **Agricultural Analysis Assistant**

I'm ready to help with your farming questions! While I can't see an image right now, I can provide expert guidance based on your descriptions.

**How I can help:**
🔍 **Plant Health Assessment** - Describe symptoms and I'll help diagnose issues
📊 **Growth Analysis** - Tell me about growth patterns and I'll provide insights  
🌡️ **Environmental Troubleshooting** - Share conditions and get optimization tips
🐛 **Pest & Disease ID** - Describe what you're seeing for identification help
💧 **Nutrient Management** - Get feeding and watering recommendations

**To get started:**
• Describe what you're seeing with your plants
• Tell me about any specific concerns or symptoms
• Ask about care for specific plant types
• Share your growing conditions for optimization tips

What would you like help with today? 🚜`,
      })
    }

    // Create comprehensive agricultural system prompt for vision analysis
    const systemPrompt = `You are AgriForce Vision AI, an expert agricultural analyst specializing in vertical farming, hydroponics, and plant health assessment. You have extensive knowledge in:

PLANT HEALTH & DIAGNOSTICS:
- Disease identification (bacterial, fungal, viral)
- Pest detection and management
- Nutrient deficiency symptoms
- Environmental stress indicators
- Growth stage assessment

VERTICAL FARMING EXPERTISE:
- Hydroponic and aeroponic systems
- LED lighting optimization
- Environmental controls (temperature, humidity, CO2)
- Space utilization and layout efficiency
- Automation and monitoring systems

CROP-SPECIFIC KNOWLEDGE:
- Leafy greens (lettuce, spinach, kale, herbs)
- Microgreens and sprouts
- Fruiting plants (tomatoes, peppers, strawberries)
- Root vegetables and specialty crops

When analyzing images, provide:
1. **Immediate Observations**: What you see in detail
2. **Health Assessment**: Overall plant condition and any issues
3. **Specific Diagnoses**: Identify diseases, pests, or deficiencies
4. **Action Plan**: Step-by-step recommendations
5. **Prevention**: How to avoid future problems
6. **Optimization**: Ways to improve growth and yield

Be thorough, practical, and encouraging. Use emojis strategically. Provide specific, actionable advice that farmers can implement immediately.`

    console.log(`Preparing Groq Vision API request with model: ${VISION_MODEL}`)

    // Prepare messages for vision API with proper format
    const messages = [
      { role: "system", content: systemPrompt },
      {
        role: "user",
        content: [
          {
            type: "text",
            text: message || "Please analyze this agricultural image and provide detailed insights.",
          },
          {
            type: "image_url",
            image_url: {
              url: `data:image/jpeg;base64,${image}`,
            },
          },
        ],
      },
    ]

    // Make direct request to the Groq API with the specific model
    const groqResponse = await fetch(GROQ_API_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: VISION_MODEL,
        messages: messages,
        temperature: 0.7,
        max_tokens: 1500,
        top_p: 1,
        stream: false,
      }),
    })

    if (!groqResponse.ok) {
      const errorText = await groqResponse.text()
      console.error("Groq API error:", groqResponse.status, errorText)

      // Try to parse error as JSON for better error messages
      let errorDetails = errorText
      try {
        const errorJson = JSON.parse(errorText)
        errorDetails = errorJson.error?.message || errorText
      } catch {
        // Keep original error text if not JSON
      }

      // Check if it's a model-specific error
      if (errorDetails.includes("not found") || errorDetails.includes("not supported")) {
        return Response.json({
          response: `🔧 **Vision Model Update Required**

The specific vision model (${VISION_MODEL}) is currently being updated or is not available.

**🌱 AGRICULTURAL SUPPORT AVAILABLE:**

**What I can help with right now:**
🔍 **Plant Health Analysis** - Describe symptoms for expert diagnosis
📊 **Growth Optimization** - Get recommendations for better yields
🌡️ **Environmental Tuning** - Optimize temperature, humidity, lighting
🐛 **Pest & Disease ID** - Identify issues from descriptions
💧 **Nutrient Management** - Balance feeding schedules

**📝 HOW TO GET HELP:**
1. **Describe your plants**: Colors, patterns, growth issues
2. **Share symptoms**: Wilting, spots, discoloration, pests
3. **Provide context**: Plant type, growing setup, timeline

**🚀 QUICK SOLUTIONS:**

**Common Issues:**
• **Yellow leaves**: Usually nitrogen deficiency or pH imbalance
• **Brown spots**: Possible fungal infection or nutrient burn
• **Wilting**: Check water levels and root health
• **Slow growth**: Review lighting schedule and nutrient concentration

**💬 Use the Assistant tab** for detailed, personalized farming guidance!

What specific issues are you seeing with your plants? 🌿`,
          fallback: true,
        })
      }

      return Response.json(
        {
          error: "Failed to get response from Groq API",
          details: `Status ${groqResponse.status}: ${errorDetails}`,
        },
        { status: 500 },
      )
    }

    // Parse the successful Groq response
    const groqData = await groqResponse.json()
    const responseContent = groqData.choices?.[0]?.message?.content || "Sorry, I couldn't analyze the image."

    console.log(`Groq Vision API response received successfully with model: ${VISION_MODEL}`)

    return Response.json({
      response: responseContent,
      model: VISION_MODEL,
      success: true,
    })
  } catch (error) {
    console.error("Detailed error in vision API:", error)

    return Response.json(
      {
        response: `🔧 **Agricultural Support Available**

There's a temporary issue with the vision analysis service, but I'm still here to help with your farming needs!

**🌱 WHAT I CAN DO RIGHT NOW:**

**Expert Guidance:**
• Plant disease and pest identification from descriptions
• Growth optimization recommendations  
• Environmental troubleshooting
• Nutrient management advice
• Harvest timing guidance

**📝 HOW TO GET HELP:**
1. **Describe your plants**: Tell me what you're seeing
2. **Share symptoms**: Colors, patterns, growth issues
3. **Provide context**: Plant type, growing conditions, timeline

**🚀 QUICK SOLUTIONS:**

**For Immediate Issues:**
• **Wilting**: Check water levels and root health
• **Yellow leaves**: Likely nutrient or pH issue (check 6.0-6.5 pH)
• **Slow growth**: Review lighting and feeding schedule
• **Spots/discoloration**: Possible disease or pest problem

**💬 Use the Assistant tab** for detailed, personalized farming advice!

**🔄 Vision Analysis**: Will be restored with model updates

What's happening with your plants? Describe what you're seeing and I'll provide expert guidance! 🌿`,
        error: true,
      },
      { status: 200 },
    )
  }
}
