"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useFarm } from "../contexts/farm-context"
import { useAuth } from "../contexts/auth-context"
import SystemSelector from "../components/system-selector"
import FarmSection from "../components/farm-section"
import TowerFarmSection from "../components/tower-farm-section"
import AFrameFarmSection from "../components/aframe-farm-section"
import LocalChatSection from "../components/local-chat-section"
import VisionSection from "../components/vision-section"
import EnvironmentalControls from "../components/environmental-controls"
import GrowthTracking from "../components/growth-tracking"
import ProtectedRoute from "../components/auth/protected-route"
import { Sprout, MessageCircle, Settings, Thermometer, LineChart, Eye, User } from "lucide-react"
import Link from "next/link"

function DashboardContent() {
  const { systemType } = useFarm()
  const { user } = useAuth()
  const [showSystemSelector, setShowSystemSelector] = useState(false)

  const renderFarmSection = () => {
    switch (systemType) {
      case "tower":
        return <TowerFarmSection />
      case "a-frame":
        return <AFrameFarmSection />
      default:
        return <FarmSection />
    }
  }

  const getSystemName = () => {
    switch (systemType) {
      case "tower":
        return "Tower Farming"
      case "a-frame":
        return "A-Frame System"
      default:
        return "Vertical Rack Farming"
    }
  }

  if (showSystemSelector) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
        <div className="container mx-auto p-4">
          <header className="text-center mb-8">
            <h1 className="text-4xl font-bold text-green-800 mb-2">AgriForce</h1>
            <p className="text-green-600">What farming was meant to be</p>
          </header>
          <SystemSelector />
          <div className="text-center mt-6">
            <button
              onClick={() => setShowSystemSelector(false)}
              className="text-green-600 hover:text-green-800 text-sm underline"
            >
              Continue with {getSystemName()}
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      <div className="container mx-auto p-4">
        <header className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2">
            <h1 className="text-4xl font-bold text-green-800">AgriForce</h1>
            <button
              onClick={() => setShowSystemSelector(true)}
              className="p-2 text-green-600 hover:text-green-800 hover:bg-green-100 rounded-full transition-colors"
              title="Change farming system"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="text-green-600 text-sm">{getSystemName()}</p>
              <p className="text-green-800 font-medium">{user?.fullName || user?.email}</p>
            </div>
            <Link href="/profile">
              <button className="p-2 bg-green-600 text-white rounded-full hover:bg-green-700 transition-colors">
                <User className="w-5 h-5" />
              </button>
            </Link>
          </div>
        </header>

        <Tabs defaultValue="farm" className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-6 max-w-3xl mx-auto">
            <TabsTrigger value="farm" className="flex items-center gap-2">
              <Sprout className="w-4 h-4" />
              Farm
            </TabsTrigger>
            <TabsTrigger value="environment" className="flex items-center gap-2">
              <Thermometer className="w-4 h-4" />
              Environment
            </TabsTrigger>
            <TabsTrigger value="growth" className="flex items-center gap-2">
              <LineChart className="w-4 h-4" />
              Growth
            </TabsTrigger>
            <TabsTrigger value="vision" className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              Vision
            </TabsTrigger>
            <TabsTrigger value="chat" className="flex items-center gap-2">
              <MessageCircle className="w-4 h-4" />
              Assistant
            </TabsTrigger>
          </TabsList>

          <TabsContent value="farm" className="mt-0">
            {renderFarmSection()}
          </TabsContent>

          <TabsContent value="environment" className="mt-0">
            <EnvironmentalControls />
          </TabsContent>

          <TabsContent value="growth" className="mt-0">
            <GrowthTracking />
          </TabsContent>

          <TabsContent value="vision" className="mt-0">
            <VisionSection />
          </TabsContent>

          <TabsContent value="chat" className="mt-0">
            <LocalChatSection />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

export default function DashboardPage() {
  return (
    <ProtectedRoute>
      <DashboardContent />
    </ProtectedRoute>
  )
}
