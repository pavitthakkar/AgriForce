import ProtectedRoute from "@/app/components/auth/protected-route"
import UserProfile from "@/app/components/user-profile"

export default function ProfilePage() {
  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 flex flex-col items-center justify-center p-4">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-green-800 mb-2">AgriForce</h1>
          <p className="text-green-600">Your Profile</p>
        </div>
        <UserProfile />
      </div>
    </ProtectedRoute>
  )
}
