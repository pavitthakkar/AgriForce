"use client"

import { createContext, useEffect, useState, type ReactNode } from "react"
import { useAuth } from "./auth-context"
import { farmService } from "@/lib/db-service"
import { useToast } from "@/components/ui/use-toast"
import { useContext } from "react"

export interface PlantNote {
  id: string
  date: string
  note: string
}

export interface PlantModule {
  id: string
  type: string
  plantedDate: string
  health: "excellent" | "good" | "fair" | "poor"
  notes: PlantNote[]
  position: { row: number; col: number }
  // For tower farming
  tower?: number
  level?: number
  // For A-frame farming
  frame?: number
  side?: "left" | "right"
}

export interface LightingSystem {
  id: string
  position: { row: number; col: number }
  intensity: number // 1-100
  coverage: number // radius of coverage
  type: "LED" | "Fluorescent" | "Incandescent" | "HPS" | "CMH" | "T5" | "CFL" // lighting type
  // For tower farming
  tower?: number
  // For A-frame farming
  frame?: number
}

export interface IrrigationPipe {
  id: string
  from: { row: number; col: number }
  to: { row: number; col: number }
  type: "main" | "branch" // main pipes are thicker
  // For tower farming
  fromTower?: number
  toTower?: number
  fromLevel?: number
  toLevel?: number
  // For A-frame farming
  fromFrame?: number
  toFrame?: number
  fromSide?: "left" | "right"
  toSide?: "left" | "right"
}

export interface FarmSize {
  rows: number
  cols: number
  // For tower farming
  towers?: number
  levelsPerTower?: number
  // For A-frame farming
  frames?: number
  levelsPerFrame?: number
}

export type FarmingSystemType = "vertical-rack" | "tower" | "a-frame"

interface FarmContextType {
  modules: PlantModule[]
  lighting: LightingSystem[]
  irrigation: IrrigationPipe[]
  farmSize: FarmSize
  systemType: FarmingSystemType
  isLoading: boolean
  setSystemType: (type: FarmingSystemType) => void
  addModule: (module: Omit<PlantModule, "id">) => boolean
  removeModule: (id: string) => void
  updateModule: (id: string, updates: Partial<PlantModule>) => void
  addNote: (moduleId: string, note: string) => void
  addLighting: (lighting: Omit<LightingSystem, "id">) => boolean
  removeLighting: (id: string) => void
  addIrrigationPipe: (pipe: Omit<IrrigationPipe, "id">) => void
  removeIrrigationPipe: (id: string) => void
  updateFarmSize: (size: FarmSize) => void
  getFarmSummary: () => string
  syncWithDatabase: () => Promise<void>
}

const FarmContext = createContext<FarmContextType | undefined>(undefined)

export function FarmProvider({ children }: { children: ReactNode }) {
  const [modules, setModules] = useState<PlantModule[]>([])
  const [lighting, setLighting] = useState<LightingSystem[]>([])
  const [irrigation, setIrrigation] = useState<IrrigationPipe[]>([])
  const [systemType, setSystemType] = useState<FarmingSystemType>("vertical-rack")
  const [farmSize, setFarmSize] = useState<FarmSize>({
    rows: 6,
    cols: 8,
    towers: 4,
    levelsPerTower: 6,
    frames: 3,
    levelsPerFrame: 5,
  })
  const [isLoading, setIsLoading] = useState(true)
  const { user } = useAuth()
  const { toast } = useToast()

  // Create user-specific localStorage keys
  const getUserKey = (key: string) => {
    return user ? `vertical-farm-${key}-${user.id}` : `vertical-farm-${key}`
  }

  // Load user-specific data from localStorage
  useEffect(() => {
    if (user) {
      const savedModules = localStorage.getItem(getUserKey("modules"))
      if (savedModules) {
        setModules(JSON.parse(savedModules))
      } else {
        setModules([]) // Clear modules for new user
      }

      const savedLighting = localStorage.getItem(getUserKey("lighting"))
      if (savedLighting) {
        setLighting(JSON.parse(savedLighting))
      } else {
        setLighting([]) // Clear lighting for new user
      }

      const savedIrrigation = localStorage.getItem(getUserKey("irrigation"))
      if (savedIrrigation) {
        setIrrigation(JSON.parse(savedIrrigation))
      } else {
        setIrrigation([]) // Clear irrigation for new user
      }

      const savedSize = localStorage.getItem(getUserKey("size"))
      if (savedSize) {
        setFarmSize(JSON.parse(savedSize))
      } else {
        // Reset to default for new user
        setFarmSize({
          rows: 6,
          cols: 8,
          towers: 4,
          levelsPerTower: 6,
          frames: 3,
          levelsPerFrame: 5,
        })
      }

      const savedSystemType = localStorage.getItem(getUserKey("system-type"))
      if (savedSystemType) {
        setSystemType(savedSystemType as FarmingSystemType)
      } else {
        setSystemType("vertical-rack") // Reset to default for new user
      }

      setIsLoading(false)
    } else {
      // Clear all data when user logs out
      setModules([])
      setLighting([])
      setIrrigation([])
      setSystemType("vertical-rack")
      setFarmSize({
        rows: 6,
        cols: 8,
        towers: 4,
        levelsPerTower: 6,
        frames: 3,
        levelsPerFrame: 5,
      })
      setIsLoading(false)
    }
  }, [user])

  // Save to user-specific localStorage whenever data changes
  useEffect(() => {
    if (user) {
      localStorage.setItem(getUserKey("modules"), JSON.stringify(modules))
    }
  }, [modules, user])

  useEffect(() => {
    if (user) {
      localStorage.setItem(getUserKey("lighting"), JSON.stringify(lighting))
    }
  }, [lighting, user])

  useEffect(() => {
    if (user) {
      localStorage.setItem(getUserKey("irrigation"), JSON.stringify(irrigation))
    }
  }, [irrigation, user])

  useEffect(() => {
    if (user) {
      localStorage.setItem(getUserKey("size"), JSON.stringify(farmSize))
    }
  }, [farmSize, user])

  useEffect(() => {
    if (user) {
      localStorage.setItem(getUserKey("system-type"), systemType)
    }
  }, [systemType, user])

  // Sync data with database
  const syncWithDatabase = async () => {
    if (!user) return

    try {
      setIsLoading(true)

      // Save farm configuration
      await farmService.saveFarmConfig(user.id, systemType, farmSize)

      // Save plant modules
      await farmService.savePlantModules(user.id, modules)

      // Save lighting systems
      await farmService.saveLightingSystems(user.id, lighting)

      // Save irrigation pipes
      await farmService.saveIrrigationPipes(user.id, irrigation)

      toast({
        title: "Data synchronized",
        description: "Your farm data has been saved to the cloud",
      })
    } catch (error) {
      console.error("Error syncing with database:", error)
      toast({
        title: "Sync failed",
        description: "Failed to save your farm data to the cloud. Your data is still saved locally.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getFarmSummary = () => {
    const plantTypes = [...new Set(modules.map((m) => m.type))]
    const healthCounts = modules.reduce(
      (acc, m) => {
        acc[m.health] = (acc[m.health] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    )

    return `${systemType} farm with ${modules.length} plants (${plantTypes.join(", ")}), ${
      lighting.length
    } lighting systems, and ${irrigation.length} irrigation pipes.`
  }

  const addModule = (module: Omit<PlantModule, "id">) => {
    if (!user) return false

    const newModule: PlantModule = {
      ...module,
      id: crypto.randomUUID(),
    } as PlantModule

    setModules((prev) => [...prev, newModule])
    return true
  }

  const removeModule = (id: string) => {
    setModules((prev) => prev.filter((module) => module.id !== id))
  }

  const updateModule = (id: string, updates: Partial<PlantModule>) => {
    setModules((prev) => prev.map((module) => (module.id === id ? { ...module, ...updates } : module)))
  }

  const addNote = (moduleId: string, note: string) => {
    const newNote: PlantNote = {
      id: crypto.randomUUID(),
      date: new Date().toLocaleDateString(),
      note,
    }

    setModules((prev) =>
      prev.map((module) => (module.id === moduleId ? { ...module, notes: [...module.notes, newNote] } : module)),
    )
  }

  const addLighting = (lighting: Omit<LightingSystem, "id">) => {
    if (!user) return false

    const newLighting: LightingSystem = {
      ...lighting,
      id: crypto.randomUUID(),
    } as LightingSystem

    setLighting((prev) => [...prev, newLighting])
    return true
  }

  const removeLighting = (id: string) => {
    setLighting((prev) => prev.filter((light) => light.id !== id))
  }

  const addIrrigationPipe = (pipe: Omit<IrrigationPipe, "id">) => {
    const newPipe: IrrigationPipe = {
      ...pipe,
      id: crypto.randomUUID(),
    } as IrrigationPipe

    setIrrigation((prev) => [...prev, newPipe])
  }

  const removeIrrigationPipe = (id: string) => {
    setIrrigation((prev) => prev.filter((pipe) => pipe.id !== id))
  }

  const updateFarmSize = (size: FarmSize) => {
    setFarmSize(size)
  }

  return (
    <FarmContext.Provider
      value={{
        modules,
        lighting,
        irrigation,
        farmSize,
        systemType,
        isLoading,
        setSystemType,
        addModule,
        removeModule,
        updateModule,
        addNote,
        addLighting,
        removeLighting,
        addIrrigationPipe,
        removeIrrigationPipe,
        updateFarmSize,
        getFarmSummary,
        syncWithDatabase,
      }}
    >
      {children}
    </FarmContext.Provider>
  )
}

export function useFarm() {
  const context = useContext(FarmContext)
  if (context === undefined) {
    throw new Error("useFarm must be used within a FarmProvider")
  }
  return context
}
