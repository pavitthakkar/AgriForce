"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState } from "react"
import { FileDatabase, type User } from "@/lib/file-db"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"

interface AuthContextType {
  user: User | null
  loading: boolean
  isLoading: boolean // Added for compatibility with existing code
  signIn: (email: string, password: string) => Promise<{ error?: string }>
  signUp: (email: string, password: string, fullName?: string) => Promise<{ error?: string }>
  signOut: () => Promise<void>
  updateProfile: (data: { fullName?: string }) => Promise<{ error?: string }>
  resetPassword: (email: string) => Promise<{ error?: string }>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()
  const router = useRouter()

  // Check for existing session and validate it
  useEffect(() => {
    const checkSession = async () => {
      try {
        const sessionUser = localStorage.getItem("auth_user")
        const sessionTimestamp = localStorage.getItem("auth_timestamp")

        if (sessionUser && sessionTimestamp) {
          const userData = JSON.parse(sessionUser)
          const timestamp = Number.parseInt(sessionTimestamp)
          const now = Date.now()

          // Session expires after 30 days
          const SESSION_DURATION = 30 * 24 * 60 * 60 * 1000

          if (now - timestamp < SESSION_DURATION) {
            // Validate user still exists in database
            const users = await FileDatabase.getUsers()
            const validUser = users.find((u) => u.id === userData.id)

            if (validUser) {
              setUser(validUser)
              // Update timestamp for session extension
              localStorage.setItem("auth_timestamp", now.toString())
            } else {
              // User no longer exists, clear session
              localStorage.removeItem("auth_user")
              localStorage.removeItem("auth_timestamp")
            }
          } else {
            // Session expired
            localStorage.removeItem("auth_user")
            localStorage.removeItem("auth_timestamp")
          }
        }
      } catch (error) {
        console.error("Error checking session:", error)
        localStorage.removeItem("auth_user")
        localStorage.removeItem("auth_timestamp")
      }
      setLoading(false)
    }

    checkSession()
  }, [])

  const signIn = async (email: string, password: string) => {
    try {
      setLoading(true)

      // Get users from localStorage
      const users = await FileDatabase.getUsers()
      const user = users.find((u) => u.email === email)

      if (!user) {
        return { error: "User not found" }
      }

      // In production, you'd hash and compare passwords properly
      if (user.password !== password) {
        return { error: "Invalid password" }
      }

      setUser(user)
      const timestamp = Date.now().toString()
      localStorage.setItem("auth_user", JSON.stringify(user))
      localStorage.setItem("auth_timestamp", timestamp)

      toast({
        title: "Signed in successfully",
        description: `Welcome back, ${user.fullName || email}!`,
      })

      // Redirect to dashboard
      router.replace("/dashboard")
      return {}
    } catch (error) {
      console.error("Sign in error:", error)
      return { error: "An error occurred during sign in" }
    } finally {
      setLoading(false)
    }
  }

  const signUp = async (email: string, password: string, fullName?: string) => {
    try {
      setLoading(true)

      // Get users from localStorage
      const users = await FileDatabase.getUsers()
      const existingUser = users.find((u) => u.email === email)

      if (existingUser) {
        return { error: "User already exists" }
      }

      const newUser = {
        id: crypto.randomUUID(),
        email,
        password, // In production, hash this
        fullName,
        createdAt: new Date().toISOString(),
      }

      // Add user to localStorage
      users.push(newUser)
      localStorage.setItem("db_users.json", JSON.stringify(users))

      setUser(newUser)
      const timestamp = Date.now().toString()
      localStorage.setItem("auth_user", JSON.stringify(newUser))
      localStorage.setItem("auth_timestamp", timestamp)

      toast({
        title: "Account created successfully",
        description: "Welcome to AgriForce!",
      })

      // Redirect to dashboard
      router.replace("/dashboard")
      return {}
    } catch (error) {
      console.error("Sign up error:", error)
      return { error: "An error occurred during sign up" }
    } finally {
      setLoading(false)
    }
  }

  const signOut = async () => {
    setUser(null)
    localStorage.removeItem("auth_user")
    localStorage.removeItem("auth_timestamp")

    toast({
      title: "Signed out",
      description: "You have been signed out successfully",
    })

    // Redirect to login
    router.replace("/login")
  }

  const updateProfile = async (data: { fullName?: string }) => {
    if (!user) return { error: "Not authenticated" }

    try {
      // Get users from localStorage
      const users = await FileDatabase.getUsers()
      const userIndex = users.findIndex((u) => u.id === user.id)

      if (userIndex >= 0) {
        users[userIndex] = { ...users[userIndex], ...data }
        localStorage.setItem("db_users.json", JSON.stringify(users))

        const updatedUser = users[userIndex]
        setUser(updatedUser)
        localStorage.setItem("auth_user", JSON.stringify(updatedUser))

        toast({
          title: "Profile updated",
          description: "Your profile has been updated successfully",
        })
      }

      return {}
    } catch (error) {
      console.error("Update profile error:", error)
      return { error: "An error occurred updating profile" }
    }
  }

  const resetPassword = async (email: string) => {
    try {
      // In a real app, you'd send an email with a reset link
      // For this demo, we'll just show a success message

      toast({
        title: "Password reset email sent",
        description: "Check your email for instructions to reset your password",
      })

      return {}
    } catch (error) {
      console.error("Reset password error:", error)
      return { error: "An error occurred sending reset email" }
    }
  }

  const value = {
    user,
    loading,
    isLoading: loading, // Added for compatibility
    signIn,
    signUp,
    signOut,
    updateProfile,
    resetPassword,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
