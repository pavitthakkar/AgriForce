"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"

export interface EnvironmentalData {
  temperature: number // in Celsius
  humidity: number // percentage
  co2Level: number // ppm (parts per million)
  lightIntensity: number // percentage
  airflow: number // percentage
  waterPh: number // pH level
  waterEc: number // Electrical conductivity (μS/cm)
  outdoorWeather: {
    temperature: number
    humidity: number
    condition: "sunny" | "cloudy" | "rainy" | "snowy" | "windy"
  }
  lastUpdated: string // ISO date string
}

export interface EnvironmentalSettings {
  targetTemperature: number
  targetHumidity: number
  targetCo2Level: number
  targetLightIntensity: number
  targetAirflow: number
  targetWaterPh: number
  targetWaterEc: number
  autoAdjust: boolean
}

export interface HistoricalData {
  timestamp: string
  temperature: number
  humidity: number
  co2Level: number
}

interface EnvironmentContextType {
  currentData: EnvironmentalData
  settings: EnvironmentalSettings
  historicalData: HistoricalData[]
  updateSettings: (newSettings: Partial<EnvironmentalSettings>) => void
  refreshData: () => void
  resetToDefaults: () => void
}

const defaultEnvironmentalData: EnvironmentalData = {
  temperature: 23,
  humidity: 65,
  co2Level: 800,
  lightIntensity: 75,
  airflow: 50,
  waterPh: 6.2,
  waterEc: 1.8,
  outdoorWeather: {
    temperature: 22,
    humidity: 60,
    condition: "sunny",
  },
  lastUpdated: new Date().toISOString(),
}

const defaultEnvironmentalSettings: EnvironmentalSettings = {
  targetTemperature: 23,
  targetHumidity: 65,
  targetCo2Level: 800,
  targetLightIntensity: 75,
  targetAirflow: 50,
  targetWaterPh: 6.2,
  targetWaterEc: 1.8,
  autoAdjust: true,
}

const EnvironmentContext = createContext<EnvironmentContextType | undefined>(undefined)

export function EnvironmentProvider({ children }: { children: ReactNode }) {
  const [currentData, setCurrentData] = useState<EnvironmentalData>(defaultEnvironmentalData)
  const [settings, setSettings] = useState<EnvironmentalSettings>(defaultEnvironmentalSettings)
  const [historicalData, setHistoricalData] = useState<HistoricalData[]>([])

  // Load data from localStorage on mount
  useEffect(() => {
    const savedSettings = localStorage.getItem("vertical-farm-env-settings")
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings))
    }

    const savedHistoricalData = localStorage.getItem("vertical-farm-env-history")
    if (savedHistoricalData) {
      setHistoricalData(JSON.parse(savedHistoricalData))
    }

    // Initialize with some historical data if none exists
    if (!savedHistoricalData) {
      const initialHistory = generateInitialHistoricalData()
      setHistoricalData(initialHistory)
      localStorage.setItem("vertical-farm-env-history", JSON.stringify(initialHistory))
    }

    // Set up interval to simulate data changes
    const interval = setInterval(() => {
      simulateEnvironmentalChanges()
    }, 60000) // Update every minute

    return () => clearInterval(interval)
  }, [])

  // Save settings to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("vertical-farm-env-settings", JSON.stringify(settings))
  }, [settings])

  // Save historical data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("vertical-farm-env-history", JSON.stringify(historicalData))
  }, [historicalData])

  // Generate initial historical data for the past 24 hours
  const generateInitialHistoricalData = () => {
    const data: HistoricalData[] = []
    const now = new Date()

    for (let i = 24; i >= 0; i--) {
      const timestamp = new Date(now.getTime() - i * 3600000).toISOString() // Go back i hours
      data.push({
        timestamp,
        temperature: 22 + Math.random() * 3 - 1, // 21-25°C
        humidity: 60 + Math.random() * 10 - 5, // 55-70%
        co2Level: 750 + Math.random() * 100, // 750-850 ppm
      })
    }

    return data
  }

  // Simulate environmental changes based on settings and random factors
  const simulateEnvironmentalChanges = () => {
    const outdoorConditions = ["sunny", "cloudy", "rainy", "snowy", "windy"]
    const randomCondition = outdoorConditions[Math.floor(Math.random() * outdoorConditions.length)] as
      | "sunny"
      | "cloudy"
      | "rainy"
      | "snowy"
      | "windy"

    // Calculate new values with some randomness but trending toward targets if autoAdjust is on
    const calculateNewValue = (current: number, target: number) => {
      if (settings.autoAdjust) {
        // Move 10-30% toward target plus small random variation
        const movePercent = 0.1 + Math.random() * 0.2
        return current + (target - current) * movePercent + (Math.random() * 0.6 - 0.3)
      } else {
        // Just add random variation
        return current + (Math.random() * 2 - 1)
      }
    }

    const newData: EnvironmentalData = {
      temperature: calculateNewValue(currentData.temperature, settings.targetTemperature),
      humidity: calculateNewValue(currentData.humidity, settings.targetHumidity),
      co2Level: calculateNewValue(currentData.co2Level, settings.targetCo2Level),
      lightIntensity: calculateNewValue(currentData.lightIntensity, settings.targetLightIntensity),
      airflow: calculateNewValue(currentData.airflow, settings.targetAirflow),
      waterPh: calculateNewValue(currentData.waterPh, settings.targetWaterPh),
      waterEc: calculateNewValue(currentData.waterEc, settings.targetWaterEc),
      outdoorWeather: {
        temperature: currentData.outdoorWeather.temperature + (Math.random() * 2 - 1),
        humidity: currentData.outdoorWeather.humidity + (Math.random() * 5 - 2.5),
        condition: randomCondition,
      },
      lastUpdated: new Date().toISOString(),
    }

    setCurrentData(newData)

    // Add to historical data every hour (we're simulating this by checking if minutes are close to 0)
    const now = new Date()
    if (now.getMinutes() < 5) {
      const newHistoricalPoint: HistoricalData = {
        timestamp: now.toISOString(),
        temperature: newData.temperature,
        humidity: newData.humidity,
        co2Level: newData.co2Level,
      }

      setHistoricalData((prev) => {
        // Keep only the last 24 hours of data
        const newHistory = [...prev, newHistoricalPoint]
        if (newHistory.length > 24) {
          return newHistory.slice(newHistory.length - 24)
        }
        return newHistory
      })
    }
  }

  const updateSettings = (newSettings: Partial<EnvironmentalSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }))
  }

  const refreshData = () => {
    simulateEnvironmentalChanges()
  }

  const resetToDefaults = () => {
    setSettings(defaultEnvironmentalSettings)
  }

  return (
    <EnvironmentContext.Provider
      value={{
        currentData,
        settings,
        historicalData,
        updateSettings,
        refreshData,
        resetToDefaults,
      }}
    >
      {children}
    </EnvironmentContext.Provider>
  )
}

export function useEnvironment() {
  const context = useContext(EnvironmentContext)
  if (!context) {
    throw new Error("useEnvironment must be used within an EnvironmentProvider")
  }
  return context
}
