"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { useFarm, type PlantModule } from "./farm-context"

export interface GrowthData {
  moduleId: string
  plantType: string
  measurements: GrowthMeasurement[]
}

export interface GrowthMeasurement {
  date: string
  height: number // in cm
  width: number // in cm
  leafCount: number
  stage: "seedling" | "vegetative" | "flowering" | "fruiting" | "mature"
  imageUrl?: string
}

export interface PlantGrowthStage {
  stage: "seedling" | "vegetative" | "flowering" | "fruiting" | "mature"
  daysInStage: number
  expectedDuration: number
  nextStage: string | null
}

interface GrowthContextType {
  growthData: GrowthData[]
  addMeasurement: (moduleId: string, measurement: Omit<GrowthMeasurement, "date">) => void
  getModuleGrowthData: (moduleId: string) => GrowthData | undefined
  getGrowthStage: (moduleId: string) => PlantGrowthStage | undefined
  getGrowthRate: (moduleId: string) => number | undefined // cm per day
  predictHarvest: (moduleId: string) => string | undefined // date string
}

const GrowthContext = createContext<GrowthContextType | undefined>(undefined)

// Plant growth data by type
const plantGrowthData: Record<string, { stages: PlantGrowthStage[]; avgHeight: number }> = {
  Lettuce: {
    stages: [
      { stage: "seedling", daysInStage: 7, expectedDuration: 7, nextStage: "vegetative" },
      { stage: "vegetative", daysInStage: 21, expectedDuration: 21, nextStage: "mature" },
      { stage: "mature", daysInStage: 7, expectedDuration: 7, nextStage: null },
    ],
    avgHeight: 20,
  },
  Spinach: {
    stages: [
      { stage: "seedling", daysInStage: 7, expectedDuration: 7, nextStage: "vegetative" },
      { stage: "vegetative", daysInStage: 30, expectedDuration: 30, nextStage: "mature" },
      { stage: "mature", daysInStage: 10, expectedDuration: 10, nextStage: null },
    ],
    avgHeight: 15,
  },
  Kale: {
    stages: [
      { stage: "seedling", daysInStage: 10, expectedDuration: 10, nextStage: "vegetative" },
      { stage: "vegetative", daysInStage: 40, expectedDuration: 40, nextStage: "mature" },
      { stage: "mature", daysInStage: 15, expectedDuration: 15, nextStage: null },
    ],
    avgHeight: 30,
  },
  Basil: {
    stages: [
      { stage: "seedling", daysInStage: 5, expectedDuration: 5, nextStage: "vegetative" },
      { stage: "vegetative", daysInStage: 20, expectedDuration: 20, nextStage: "flowering" },
      { stage: "flowering", daysInStage: 15, expectedDuration: 15, nextStage: "mature" },
      { stage: "mature", daysInStage: 10, expectedDuration: 10, nextStage: null },
    ],
    avgHeight: 25,
  },
  Cilantro: {
    stages: [
      { stage: "seedling", daysInStage: 7, expectedDuration: 7, nextStage: "vegetative" },
      { stage: "vegetative", daysInStage: 25, expectedDuration: 25, nextStage: "flowering" },
      { stage: "flowering", daysInStage: 10, expectedDuration: 10, nextStage: "mature" },
      { stage: "mature", daysInStage: 8, expectedDuration: 8, nextStage: null },
    ],
    avgHeight: 20,
  },
  Arugula: {
    stages: [
      { stage: "seedling", daysInStage: 5, expectedDuration: 5, nextStage: "vegetative" },
      { stage: "vegetative", daysInStage: 20, expectedDuration: 20, nextStage: "mature" },
      { stage: "mature", daysInStage: 5, expectedDuration: 5, nextStage: null },
    ],
    avgHeight: 15,
  },
  "Swiss Chard": {
    stages: [
      { stage: "seedling", daysInStage: 10, expectedDuration: 10, nextStage: "vegetative" },
      { stage: "vegetative", daysInStage: 35, expectedDuration: 35, nextStage: "mature" },
      { stage: "mature", daysInStage: 15, expectedDuration: 15, nextStage: null },
    ],
    avgHeight: 35,
  },
  "Bok Choy": {
    stages: [
      { stage: "seedling", daysInStage: 7, expectedDuration: 7, nextStage: "vegetative" },
      { stage: "vegetative", daysInStage: 30, expectedDuration: 30, nextStage: "mature" },
      { stage: "mature", daysInStage: 8, expectedDuration: 8, nextStage: null },
    ],
    avgHeight: 25,
  },
}

export function GrowthProvider({ children }: { children: ReactNode }) {
  const { modules } = useFarm()
  const [growthData, setGrowthData] = useState<GrowthData[]>([])

  // Load data from localStorage on mount
  useEffect(() => {
    const savedGrowthData = localStorage.getItem("vertical-farm-growth-data")
    if (savedGrowthData) {
      setGrowthData(JSON.parse(savedGrowthData))
    }
  }, [])

  // Save to localStorage whenever data changes
  useEffect(() => {
    localStorage.setItem("vertical-farm-growth-data", JSON.stringify(growthData))
  }, [growthData])

  // Initialize growth data for new modules
  useEffect(() => {
    modules.forEach((module) => {
      if (!growthData.some((data) => data.moduleId === module.id)) {
        // Create initial growth data for this module
        const initialMeasurement = generateInitialMeasurement(module)

        setGrowthData((prev) => [
          ...prev,
          {
            moduleId: module.id,
            plantType: module.type,
            measurements: [initialMeasurement],
          },
        ])
      }
    })

    // Remove growth data for modules that no longer exist
    setGrowthData((prev) => prev.filter((data) => modules.some((module) => module.id === data.moduleId)))
  }, [modules])

  // Generate initial measurement based on plant type and days since planted
  const generateInitialMeasurement = (module: PlantModule): GrowthMeasurement => {
    const daysSincePlanted = Math.floor(
      (new Date().getTime() - new Date(module.plantedDate).getTime()) / (1000 * 60 * 60 * 24),
    )

    const plantData = plantGrowthData[module.type] || {
      stages: [
        { stage: "seedling", daysInStage: 7, expectedDuration: 7, nextStage: "vegetative" },
        { stage: "vegetative", daysInStage: 30, expectedDuration: 30, nextStage: "mature" },
        { stage: "mature", daysInStage: 10, expectedDuration: 10, nextStage: null },
      ],
      avgHeight: 20,
    }

    // Determine growth stage based on days since planted
    let stage: "seedling" | "vegetative" | "flowering" | "fruiting" | "mature" = "seedling"
    let daysAccumulated = 0

    for (const stageData of plantData.stages) {
      daysAccumulated += stageData.expectedDuration
      if (daysSincePlanted <= daysAccumulated) {
        stage = stageData.stage
        break
      }
    }

    if (daysSincePlanted > daysAccumulated) {
      stage = "mature"
    }

    // Calculate height based on growth stage and days
    const maxHeight = plantData.avgHeight
    let height = 0

    if (stage === "seedling") {
      height = maxHeight * 0.1 * (daysSincePlanted / plantData.stages[0].expectedDuration)
    } else if (stage === "vegetative") {
      height =
        maxHeight *
        (0.1 + 0.6 * ((daysSincePlanted - plantData.stages[0].expectedDuration) / plantData.stages[1].expectedDuration))
    } else if (stage === "flowering" || stage === "fruiting") {
      height = maxHeight * 0.8
    } else {
      height = maxHeight
    }

    // Add some randomness
    height = height * (0.9 + Math.random() * 0.2)

    return {
      date: module.plantedDate,
      height: Math.round(height * 10) / 10,
      width: Math.round(height * 0.7 * 10) / 10,
      leafCount: Math.floor(height * 0.8),
      stage,
    }
  }

  const addMeasurement = (moduleId: string, measurement: Omit<GrowthMeasurement, "date">) => {
    const date = new Date().toISOString().split("T")[0]

    setGrowthData((prev) => {
      const moduleData = prev.find((data) => data.moduleId === moduleId)

      if (moduleData) {
        return prev.map((data) => {
          if (data.moduleId === moduleId) {
            return {
              ...data,
              measurements: [...data.measurements, { ...measurement, date }],
            }
          }
          return data
        })
      } else {
        // If no data exists for this module yet
        const module = modules.find((m) => m.id === moduleId)
        if (!module) return prev

        return [
          ...prev,
          {
            moduleId,
            plantType: module.type,
            measurements: [{ ...measurement, date }],
          },
        ]
      }
    })
  }

  const getModuleGrowthData = (moduleId: string) => {
    return growthData.find((data) => data.moduleId === moduleId)
  }

  const getGrowthStage = (moduleId: string): PlantGrowthStage | undefined => {
    const moduleData = growthData.find((data) => data.moduleId === moduleId)
    if (!moduleData || moduleData.measurements.length === 0) return undefined

    const module = modules.find((m) => m.id === moduleId)
    if (!module) return undefined

    const plantData = plantGrowthData[module.type]
    if (!plantData) return undefined

    const daysSincePlanted = Math.floor(
      (new Date().getTime() - new Date(module.plantedDate).getTime()) / (1000 * 60 * 60 * 24),
    )

    // Find current stage
    let currentStage = plantData.stages[0]
    let daysAccumulated = 0

    for (const stage of plantData.stages) {
      if (daysSincePlanted <= daysAccumulated + stage.expectedDuration) {
        currentStage = {
          ...stage,
          daysInStage: daysSincePlanted - daysAccumulated,
        }
        break
      }
      daysAccumulated += stage.expectedDuration
    }

    // If beyond all stages, use the last stage
    if (daysSincePlanted > daysAccumulated) {
      const lastStage = plantData.stages[plantData.stages.length - 1]
      currentStage = {
        ...lastStage,
        daysInStage: lastStage.expectedDuration,
      }
    }

    return currentStage
  }

  const getGrowthRate = (moduleId: string): number | undefined => {
    const moduleData = growthData.find((data) => data.moduleId === moduleId)
    if (!moduleData || moduleData.measurements.length < 2) return undefined

    const measurements = [...moduleData.measurements].sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime(),
    )

    const firstMeasurement = measurements[0]
    const lastMeasurement = measurements[measurements.length - 1]

    const daysDiff =
      (new Date(lastMeasurement.date).getTime() - new Date(firstMeasurement.date).getTime()) / (1000 * 60 * 60 * 24)
    if (daysDiff === 0) return 0

    const heightDiff = lastMeasurement.height - firstMeasurement.height
    return Math.round((heightDiff / daysDiff) * 10) / 10
  }

  const predictHarvest = (moduleId: string): string | undefined => {
    const module = modules.find((m) => m.id === moduleId)
    if (!module) return undefined

    const plantData = plantGrowthData[module.type]
    if (!plantData) return undefined

    const plantedDate = new Date(module.plantedDate)
    const totalGrowthDays = plantData.stages.reduce((sum, stage) => sum + stage.expectedDuration, 0)

    const harvestDate = new Date(plantedDate)
    harvestDate.setDate(harvestDate.getDate() + totalGrowthDays)

    return harvestDate.toISOString().split("T")[0]
  }

  return (
    <GrowthContext.Provider
      value={{
        growthData,
        addMeasurement,
        getModuleGrowthData,
        getGrowthStage,
        getGrowthRate,
        predictHarvest,
      }}
    >
      {children}
    </GrowthContext.Provider>
  )
}

export function useGrowth() {
  const context = useContext(GrowthContext)
  if (!context) {
    throw new Error("useGrowth must be used within a GrowthProvider")
  }
  return context
}
