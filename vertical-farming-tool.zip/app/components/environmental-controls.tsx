"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { useEnvironment } from "../contexts/environment-context"
import {
  Thermometer,
  Droplets,
  Wind,
  Lightbulb,
  RefreshCw,
  BarChart3,
  Sun,
  Cloud,
  CloudDrizzle,
  Snowflake,
  CloudLightning,
} from "lucide-react"

export default function EnvironmentalControls() {
  const { currentData, settings, updateSettings, refreshData, resetToDefaults, historicalData } = useEnvironment()
  const [activeTab, setActiveTab] = useState("current")

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  const getWeatherIcon = (condition: string) => {
    switch (condition) {
      case "sunny":
        return <Sun className="w-8 h-8 text-yellow-500" />
      case "cloudy":
        return <Cloud className="w-8 h-8 text-gray-400" />
      case "rainy":
        return <CloudDrizzle className="w-8 h-8 text-blue-400" />
      case "snowy":
        return <Snowflake className="w-8 h-8 text-blue-200" />
      case "windy":
        return <CloudLightning className="w-8 h-8 text-gray-500" />
      default:
        return <Cloud className="w-8 h-8 text-gray-400" />
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Thermometer className="w-5 h-5 text-orange-500" />
            Environmental Controls
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">Last updated: {formatTime(currentData.lastUpdated)}</span>
            <Button variant="outline" size="icon" onClick={refreshData} title="Refresh data">
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-4">
            <TabsTrigger value="current" className="flex items-center gap-2">
              <Thermometer className="w-4 h-4" />
              Current Conditions
            </TabsTrigger>
            <TabsTrigger value="controls" className="flex items-center gap-2">
              <Slider className="w-4 h-4" />
              Controls
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              History
            </TabsTrigger>
          </TabsList>

          <TabsContent value="current" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Indoor conditions */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Indoor Environment</h3>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg flex items-center gap-3">
                    <Thermometer className="w-8 h-8 text-orange-500" />
                    <div>
                      <div className="text-sm text-gray-500">Temperature</div>
                      <div className="text-xl font-semibold">{currentData.temperature.toFixed(1)}°C</div>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg flex items-center gap-3">
                    <Droplets className="w-8 h-8 text-blue-500" />
                    <div>
                      <div className="text-sm text-gray-500">Humidity</div>
                      <div className="text-xl font-semibold">{currentData.humidity.toFixed(1)}%</div>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg flex items-center gap-3">
                    <Wind className="w-8 h-8 text-cyan-500" />
                    <div>
                      <div className="text-sm text-gray-500">CO₂ Level</div>
                      <div className="text-xl font-semibold">{currentData.co2Level.toFixed(0)} ppm</div>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg flex items-center gap-3">
                    <Lightbulb className="w-8 h-8 text-yellow-500" />
                    <div>
                      <div className="text-sm text-gray-500">Light Intensity</div>
                      <div className="text-xl font-semibold">{currentData.lightIntensity.toFixed(0)}%</div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg flex items-center gap-3">
                    <Wind className="w-8 h-8 text-gray-500" />
                    <div>
                      <div className="text-sm text-gray-500">Airflow</div>
                      <div className="text-xl font-semibold">{currentData.airflow.toFixed(0)}%</div>
                    </div>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg flex items-center gap-3">
                    <Droplets className="w-8 h-8 text-cyan-500" />
                    <div>
                      <div className="text-sm text-gray-500">Water pH</div>
                      <div className="text-xl font-semibold">{currentData.waterPh.toFixed(1)}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Outdoor conditions */}
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Outdoor Conditions</h3>

                <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-lg flex items-center justify-between">
                  <div>
                    <div className="text-sm text-gray-600 mb-1">Current Weather</div>
                    <div className="text-xl font-semibold capitalize">{currentData.outdoorWeather.condition}</div>
                    <div className="mt-2 space-y-1">
                      <div className="flex items-center gap-2 text-sm">
                        <Thermometer className="w-4 h-4 text-orange-500" />
                        <span>{currentData.outdoorWeather.temperature.toFixed(1)}°C</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Droplets className="w-4 h-4 text-blue-500" />
                        <span>{currentData.outdoorWeather.humidity.toFixed(0)}% Humidity</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-center">
                    {getWeatherIcon(currentData.outdoorWeather.condition)}
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="text-sm font-medium mb-2">System Status</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Temperature Control</span>
                      <span
                        className={`text-xs px-2 py-1 rounded-full ${Math.abs(currentData.temperature - settings.targetTemperature) < 1 ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}`}
                      >
                        {Math.abs(currentData.temperature - settings.targetTemperature) < 1 ? "Optimal" : "Adjusting"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Humidity Control</span>
                      <span
                        className={`text-xs px-2 py-1 rounded-full ${Math.abs(currentData.humidity - settings.targetHumidity) < 5 ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}`}
                      >
                        {Math.abs(currentData.humidity - settings.targetHumidity) < 5 ? "Optimal" : "Adjusting"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">CO₂ Control</span>
                      <span
                        className={`text-xs px-2 py-1 rounded-full ${Math.abs(currentData.co2Level - settings.targetCo2Level) < 50 ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}`}
                      >
                        {Math.abs(currentData.co2Level - settings.targetCo2Level) < 50 ? "Optimal" : "Adjusting"}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="controls" className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Switch
                  checked={settings.autoAdjust}
                  onCheckedChange={(checked) => updateSettings({ autoAdjust: checked })}
                />
                <span className="font-medium">Auto-adjust to target values</span>
              </div>
              <Button variant="outline" onClick={resetToDefaults}>
                Reset to Defaults
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium flex items-center gap-2">
                      <Thermometer className="w-4 h-4 text-orange-500" />
                      Temperature: {settings.targetTemperature}°C
                    </label>
                    <span
                      className={`text-xs ${Math.abs(currentData.temperature - settings.targetTemperature) < 1 ? "text-green-600" : "text-yellow-600"}`}
                    >
                      Current: {currentData.temperature.toFixed(1)}°C
                    </span>
                  </div>
                  <Slider
                    value={[settings.targetTemperature]}
                    min={15}
                    max={30}
                    step={0.5}
                    onValueChange={(value) => updateSettings({ targetTemperature: value[0] })}
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>15°C</span>
                    <span>30°C</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium flex items-center gap-2">
                      <Droplets className="w-4 h-4 text-blue-500" />
                      Humidity: {settings.targetHumidity}%
                    </label>
                    <span
                      className={`text-xs ${Math.abs(currentData.humidity - settings.targetHumidity) < 5 ? "text-green-600" : "text-yellow-600"}`}
                    >
                      Current: {currentData.humidity.toFixed(1)}%
                    </span>
                  </div>
                  <Slider
                    value={[settings.targetHumidity]}
                    min={40}
                    max={90}
                    step={1}
                    onValueChange={(value) => updateSettings({ targetHumidity: value[0] })}
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>40%</span>
                    <span>90%</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium flex items-center gap-2">
                      <Wind className="w-4 h-4 text-cyan-500" />
                      CO₂ Level: {settings.targetCo2Level} ppm
                    </label>
                    <span
                      className={`text-xs ${Math.abs(currentData.co2Level - settings.targetCo2Level) < 50 ? "text-green-600" : "text-yellow-600"}`}
                    >
                      Current: {currentData.co2Level.toFixed(0)} ppm
                    </span>
                  </div>
                  <Slider
                    value={[settings.targetCo2Level]}
                    min={400}
                    max={1500}
                    step={10}
                    onValueChange={(value) => updateSettings({ targetCo2Level: value[0] })}
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>400 ppm</span>
                    <span>1500 ppm</span>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium flex items-center gap-2">
                      <Lightbulb className="w-4 h-4 text-yellow-500" />
                      Light Intensity: {settings.targetLightIntensity}%
                    </label>
                    <span
                      className={`text-xs ${Math.abs(currentData.lightIntensity - settings.targetLightIntensity) < 5 ? "text-green-600" : "text-yellow-600"}`}
                    >
                      Current: {currentData.lightIntensity.toFixed(0)}%
                    </span>
                  </div>
                  <Slider
                    value={[settings.targetLightIntensity]}
                    min={0}
                    max={100}
                    step={1}
                    onValueChange={(value) => updateSettings({ targetLightIntensity: value[0] })}
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>0%</span>
                    <span>100%</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium flex items-center gap-2">
                      <Wind className="w-4 h-4 text-gray-500" />
                      Airflow: {settings.targetAirflow}%
                    </label>
                    <span
                      className={`text-xs ${Math.abs(currentData.airflow - settings.targetAirflow) < 5 ? "text-green-600" : "text-yellow-600"}`}
                    >
                      Current: {currentData.airflow.toFixed(0)}%
                    </span>
                  </div>
                  <Slider
                    value={[settings.targetAirflow]}
                    min={0}
                    max={100}
                    step={1}
                    onValueChange={(value) => updateSettings({ targetAirflow: value[0] })}
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>0%</span>
                    <span>100%</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium flex items-center gap-2">
                      <Droplets className="w-4 h-4 text-cyan-500" />
                      Water pH: {settings.targetWaterPh}
                    </label>
                    <span
                      className={`text-xs ${Math.abs(currentData.waterPh - settings.targetWaterPh) < 0.3 ? "text-green-600" : "text-yellow-600"}`}
                    >
                      Current: {currentData.waterPh.toFixed(1)}
                    </span>
                  </div>
                  <Slider
                    value={[settings.targetWaterPh]}
                    min={5.0}
                    max={7.5}
                    step={0.1}
                    onValueChange={(value) => updateSettings({ targetWaterPh: value[0] })}
                  />
                  <div className="flex justify-between text-xs text-gray-500">
                    <span>5.0</span>
                    <span>7.5</span>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="text-sm font-medium mb-4">24-Hour History</h3>

              <div className="h-64 relative">
                {/* Temperature graph */}
                <svg className="w-full h-full">
                  <line x1="0" y1="160" x2="100%" y2="160" stroke="#e5e7eb" strokeWidth="1" />
                  <text x="5" y="164" fontSize="10" fill="#6b7280">
                    20°C
                  </text>

                  <line x1="0" y1="120" x2="100%" y2="120" stroke="#e5e7eb" strokeWidth="1" />
                  <text x="5" y="124" fontSize="10" fill="#6b7280">
                    22°C
                  </text>

                  <line x1="0" y1="80" x2="100%" y2="80" stroke="#e5e7eb" strokeWidth="1" />
                  <text x="5" y="84" fontSize="10" fill="#6b7280">
                    24°C
                  </text>

                  <line x1="0" y1="40" x2="100%" y2="40" stroke="#e5e7eb" strokeWidth="1" />
                  <text x="5" y="44" fontSize="10" fill="#6b7280">
                    26°C
                  </text>

                  {/* Temperature line */}
                  <polyline
                    points={historicalData
                      .map((point, index) => {
                        const x = (index / (historicalData.length - 1)) * 100 + "%"
                        // Map temperature to y coordinate (20-26°C range)
                        const y = 200 - ((point.temperature - 20) / 6) * 160
                        return `${x},${y}`
                      })
                      .join(" ")}
                    fill="none"
                    stroke="#f97316"
                    strokeWidth="2"
                  />

                  {/* Data points */}
                  {historicalData.map((point, index) => {
                    const x = (index / (historicalData.length - 1)) * 100 + "%"
                    const y = 200 - ((point.temperature - 20) / 6) * 160
                    return <circle key={index} cx={x} cy={y} r="3" fill="#f97316" />
                  })}
                </svg>

                <div className="absolute bottom-0 left-0 right-0 flex justify-between text-xs text-gray-500">
                  <span>
                    {new Date(historicalData[0]?.timestamp || new Date()).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                  <span>
                    {new Date(
                      historicalData[Math.floor(historicalData.length / 2)]?.timestamp || new Date(),
                    ).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </span>
                  <span>
                    {new Date(historicalData[historicalData.length - 1]?.timestamp || new Date()).toLocaleTimeString(
                      [],
                      { hour: "2-digit", minute: "2-digit" },
                    )}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-center gap-6 mt-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                  <span className="text-xs">Temperature</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                  <span className="text-xs">Humidity</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-cyan-500 rounded-full"></div>
                  <span className="text-xs">CO₂ Level</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium mb-2">Temperature Range</h4>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs text-gray-500">Min</div>
                    <div className="font-medium">
                      {Math.min(...historicalData.map((d) => d.temperature)).toFixed(1)}°C
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Avg</div>
                    <div className="font-medium">
                      {(historicalData.reduce((sum, d) => sum + d.temperature, 0) / historicalData.length).toFixed(1)}°C
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Max</div>
                    <div className="font-medium">
                      {Math.max(...historicalData.map((d) => d.temperature)).toFixed(1)}°C
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium mb-2">Humidity Range</h4>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs text-gray-500">Min</div>
                    <div className="font-medium">{Math.min(...historicalData.map((d) => d.humidity)).toFixed(0)}%</div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Avg</div>
                    <div className="font-medium">
                      {(historicalData.reduce((sum, d) => sum + d.humidity, 0) / historicalData.length).toFixed(0)}%
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Max</div>
                    <div className="font-medium">{Math.max(...historicalData.map((d) => d.humidity)).toFixed(0)}%</div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="text-sm font-medium mb-2">CO₂ Range</h4>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs text-gray-500">Min</div>
                    <div className="font-medium">
                      {Math.min(...historicalData.map((d) => d.co2Level)).toFixed(0)} ppm
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Avg</div>
                    <div className="font-medium">
                      {(historicalData.reduce((sum, d) => sum + d.co2Level, 0) / historicalData.length).toFixed(0)} ppm
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Max</div>
                    <div className="font-medium">
                      {Math.max(...historicalData.map((d) => d.co2Level)).toFixed(0)} ppm
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
