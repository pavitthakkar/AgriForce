"use client"

import React from "react"

import { useState, useRef, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Camera, Send, Eye, User, AlertCircle, X, RefreshCw, MessageCircle, XCircle, Zap } from "lucide-react"

interface VisionMessage {
  id: string
  role: "user" | "assistant" | "error" | "system"
  content: string
  image?: string
  timestamp: Date
  isVisionAnalysis?: boolean
  model?: string
}

export default function VisionSection() {
  const [messages, setMessages] = useState<VisionMessage[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        "Welcome to AgriForce Vision! 📸 I'm powered by the advanced **LLaMA-4 Scout** vision model for precise agricultural analysis.\n\n**What I can analyze:**\n🌱 Plant health and disease identification\n📊 Growth stage assessment and recommendations\n🐛 Pest detection and treatment guidance\n🌡️ Environmental condition evaluation\n💧 Nutrient deficiency diagnosis\n🔬 Detailed leaf and root analysis\n\n**Upload a clear image** of your plants, farm setup, or any agricultural concern for expert AI analysis. Let's optimize your growing success! 🚜✨",
      timestamp: new Date(),
    },
  ])
  const [prompt, setPrompt] = useState("")
  const [selectedImage, setSelectedImage] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [visionStatus, setVisionStatus] = useState<"unknown" | "available" | "unavailable">("unknown")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to bottom when new messages arrive
  React.useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector("[data-radix-scroll-area-viewport]")
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight
      }
    }
  }, [messages])

  const handleImageUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      // Validate file type
      if (!file.type.startsWith("image/")) {
        alert("Please select an image file (JPG, PNG, GIF, WebP).")
        return
      }

      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        alert("Image size must be less than 10MB. Please compress your image and try again.")
        return
      }

      const reader = new FileReader()
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if ((!prompt.trim() && !selectedImage) || isLoading) return

    const userMessage: VisionMessage = {
      id: Date.now().toString(),
      role: "user",
      content: prompt.trim() || "Please analyze this agricultural image with LLaMA-4 Scout",
      image: selectedImage || undefined,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setPrompt("")
    const currentImage = selectedImage
    setSelectedImage(null)
    setIsLoading(true)

    try {
      let base64Image = null
      if (currentImage) {
        base64Image = currentImage.split(",")[1]
      }

      console.log("Sending vision request to /api/vision with LLaMA-4 Scout model")

      const response = await fetch("/api/vision", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: userMessage.content,
          image: base64Image,
        }),
      })

      const data = await response.json()
      console.log("Vision API response:", { status: response.status, data })

      // Determine if this was a successful vision analysis
      const isVisionAnalysis = response.ok && data.success && !data.fallback && !data.error && currentImage

      // Update vision status based on response
      if (isVisionAnalysis) {
        setVisionStatus("available")
      } else if (data.fallback || data.error) {
        setVisionStatus("unavailable")
      }

      const assistantMessage: VisionMessage = {
        id: (Date.now() + 1).toString(),
        role: data.error ? "error" : data.fallback ? "system" : "assistant",
        content: data.response,
        timestamp: new Date(),
        isVisionAnalysis,
        model: data.model,
      }

      setMessages((prev) => [...prev, assistantMessage])
      setIsLoading(false)
    } catch (error) {
      console.error("Error calling vision API:", error)
      setVisionStatus("unavailable")

      const errorMessage: VisionMessage = {
        id: (Date.now() + 1).toString(),
        role: "error",
        content: `❌ **Connection Error**

I'm having trouble connecting to the LLaMA-4 Scout vision model.

**What happened:**
${error instanceof Error ? error.message : "Network or service error"}

**🌱 ALTERNATIVE SUPPORT:**

**Immediate Help:**
• **Use the Assistant tab** for expert text-based guidance
• **Describe your observations** and I'll provide detailed advice
• **All other farm features** are working normally

**Common Quick Fixes:**
• **Yellowing leaves**: Check pH (6.0-6.5) and nitrogen levels
• **Wilting plants**: Verify water levels and root health  
• **Slow growth**: Review lighting duration and nutrient concentration
• **Spots on leaves**: Likely disease - improve air circulation

**💬 Switch to Assistant tab** for comprehensive plant care guidance!

What specific issues are you seeing? I'm here to help! 🚜`,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, errorMessage])
      setIsLoading(false)
    }
  }

  const handleQuickPrompt = (quickPrompt: string) => {
    setPrompt(quickPrompt)
  }

  const testVisionService = async () => {
    setIsLoading(true)

    const testMessage: VisionMessage = {
      id: Date.now().toString(),
      role: "system",
      content: `🔧 **Testing LLaMA-4 Scout Vision Model...**\n\nChecking connection to meta-llama/llama-4-scout-17b-16e-instruct...`,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, testMessage])

    try {
      const response = await fetch("/api/vision", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: "Test LLaMA-4 Scout vision model connectivity and availability",
          image: null,
        }),
      })

      const data = await response.json()

      const isWorking = response.ok && !data.error && !data.fallback
      setVisionStatus(isWorking ? "available" : "unavailable")

      const resultMessage: VisionMessage = {
        id: (Date.now() + 1).toString(),
        role: isWorking ? "assistant" : "error",
        content: `🔧 **LLaMA-4 Scout Vision Test Results**

**Model:** meta-llama/llama-4-scout-17b-16e-instruct
**Status:** ${isWorking ? "✅ Vision Analysis Ready" : "⚠️ Model Unavailable"}
**Response Time:** ${Date.now() - Number.parseInt(testMessage.id)}ms
**Service:** ${isWorking ? "Fully Operational" : "Limited Functionality"}

${
  isWorking
    ? "🎉 **Excellent!** LLaMA-4 Scout vision model is active and ready for agricultural analysis. Upload an image of your plants for detailed AI-powered insights!"
    : "🔄 **Model Update in Progress**\n\nThe LLaMA-4 Scout vision model is being updated. Use these alternatives:\n\n• **Assistant Tab**: Expert text-based plant analysis\n• **Describe symptoms**: I'll provide detailed diagnosis\n• **Environmental monitoring**: All other features working normally"
}

**Available Features:**
✅ Plant health assessment (text-based)
✅ Environmental monitoring and controls  
✅ Growth tracking and predictions
✅ Farm layout and management
${isWorking ? "✅ LLaMA-4 Scout vision analysis" : "🔄 Vision analysis (updating)"}`,
        timestamp: new Date(),
        model: "meta-llama/llama-4-scout-17b-16e-instruct",
      }

      setMessages((prev) => [...prev, resultMessage])
      setIsLoading(false)
    } catch (error) {
      setVisionStatus("unavailable")

      const errorMessage: VisionMessage = {
        id: (Date.now() + 1).toString(),
        role: "error",
        content: `❌ **LLaMA-4 Scout Connection Failed**

Could not connect to the meta-llama/llama-4-scout-17b-16e-instruct vision model.

**Error Details:** ${error instanceof Error ? error.message : "Unknown connection error"}

**🌱 Don't worry - I can still help!**

**Available Support:**
• **Assistant Tab**: Comprehensive plant care guidance
• **Environmental Controls**: Monitor and optimize growing conditions
• **Growth Tracking**: Monitor plant development
• **Farm Management**: Full layout and planning tools

**For Plant Issues:**
• Describe symptoms and I'll provide expert diagnosis
• Share photos via other platforms and describe what you see
• Use the text-based assistant for detailed care instructions

All core farming features are fully operational! 🚜`,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, errorMessage])
      setIsLoading(false)
    }
  }

  const switchToAssistant = () => {
    // Find and click the Assistant tab
    const assistantTab = document.querySelector('[value="chat"]') as HTMLElement
    if (assistantTab) {
      assistantTab.click()
    }
  }

  const quickPrompts = [
    "Analyze plant health with LLaMA-4 Scout vision",
    "Identify diseases and provide treatment plan",
    "Assess growth stage and next care steps",
    "Evaluate environmental conditions in setup",
    "Diagnose nutrient deficiencies from leaves",
    "Check for pest damage and solutions",
  ]

  const getStatusBadge = () => {
    switch (visionStatus) {
      case "available":
        return (
          <Badge variant="default" className="bg-green-100 text-green-800">
            <Zap className="w-3 h-3 mr-1" />
            LLaMA-4 Scout Active
          </Badge>
        )
      case "unavailable":
        return (
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
            <XCircle className="w-3 h-3 mr-1" />
            Model Updating
          </Badge>
        )
      default:
        return (
          <Badge variant="outline">
            <Eye className="w-3 h-3 mr-1" />
            LLaMA-4 Scout
          </Badge>
        )
    }
  }

  return (
    <div className="w-full max-w-4xl mx-auto">
      <Card className="h-[600px] flex flex-col">
        <CardHeader className="pb-4 flex-shrink-0">
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Eye className="w-5 h-5 text-green-600" />
              AgriForce Vision
              {getStatusBadge()}
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={testVisionService}
                title="Test LLaMA-4 Scout Model"
                disabled={isLoading}
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? "animate-spin" : ""}`} />
              </Button>
              <Button variant="outline" size="sm" onClick={switchToAssistant} title="Switch to Text Assistant">
                <MessageCircle className="w-4 h-4" />
              </Button>
            </div>
          </CardTitle>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col p-0 min-h-0">
          <ScrollArea ref={scrollAreaRef} className="flex-1 px-4">
            <div className="space-y-4 py-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-3 w-full ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`flex gap-3 max-w-[85%] min-w-0 ${
                      message.role === "user" ? "flex-row-reverse" : "flex-row"
                    }`}
                  >
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                        message.role === "user"
                          ? "bg-blue-500 text-white"
                          : message.role === "error"
                            ? "bg-red-500 text-white"
                            : message.role === "system"
                              ? "bg-yellow-500 text-white"
                              : "bg-green-500 text-white"
                      }`}
                    >
                      {message.role === "user" ? (
                        <User className="w-4 h-4" />
                      ) : message.role === "error" ? (
                        <AlertCircle className="w-4 h-4" />
                      ) : (
                        <Eye className="w-4 h-4" />
                      )}
                    </div>
                    <div
                      className={`rounded-lg p-3 min-w-0 flex-1 ${
                        message.role === "user"
                          ? "bg-blue-500 text-white"
                          : message.role === "error"
                            ? "bg-red-50 text-red-900 border border-red-200"
                            : message.role === "system"
                              ? "bg-yellow-50 text-yellow-900 border border-yellow-200"
                              : "bg-gray-100 text-gray-900 border"
                      }`}
                    >
                      {message.image && (
                        <div className="mb-3">
                          <img
                            src={message.image || "/placeholder.svg"}
                            alt="Uploaded for analysis"
                            className="max-w-full h-auto rounded-lg border max-h-48 object-contain"
                          />
                          {message.isVisionAnalysis && (
                            <div className="mt-2 flex gap-2">
                              <Badge variant="default" className="bg-green-100 text-green-800 text-xs">
                                <Zap className="w-3 h-3 mr-1" />
                                LLaMA-4 Scout Analysis
                              </Badge>
                              {message.model && (
                                <Badge variant="outline" className="text-xs">
                                  {message.model}
                                </Badge>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                      <div className="text-sm whitespace-pre-wrap break-words overflow-wrap-anywhere">
                        {message.content}
                      </div>
                      <div
                        className={`text-xs mt-1 opacity-70 ${
                          message.role === "user"
                            ? "text-blue-100"
                            : message.role === "error"
                              ? "text-red-600"
                              : message.role === "system"
                                ? "text-yellow-600"
                                : "text-gray-500"
                        }`}
                      >
                        {message.timestamp.toLocaleTimeString()}
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex gap-3 justify-start w-full">
                  <div className="w-8 h-8 rounded-full bg-green-500 text-white flex items-center justify-center flex-shrink-0">
                    <Eye className="w-4 h-4" />
                  </div>
                  <div className="bg-gray-100 border rounded-lg p-3 min-w-0 flex-1 max-w-[85%]">
                    <div className="text-sm text-gray-600 flex items-center gap-2">
                      <div className="animate-pulse">
                        {selectedImage ? "LLaMA-4 Scout analyzing image..." : "Processing with LLaMA-4 Scout..."}
                      </div>
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.1s" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          <div className="border-t bg-white p-4 flex-shrink-0">
            {/* Image upload section */}
            {selectedImage && (
              <div className="mb-4 relative">
                <div className="relative inline-block">
                  <img
                    src={selectedImage || "/placeholder.svg"}
                    alt="Selected for analysis"
                    className="max-w-32 h-auto rounded-lg border"
                  />
                  <Button
                    variant="destructive"
                    size="sm"
                    className="absolute -top-2 -right-2 w-6 h-6 p-0 rounded-full"
                    onClick={() => setSelectedImage(null)}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
                <div className="mt-2">
                  <Badge variant="outline" className="text-xs">
                    <Zap className="w-3 h-3 mr-1" />
                    Ready for LLaMA-4 Scout analysis
                  </Badge>
                </div>
              </div>
            )}

            {/* Quick prompts */}
            <div className="mb-3">
              <div className="text-xs text-gray-500 mb-2">Quick LLaMA-4 Scout prompts:</div>
              <div className="flex flex-wrap gap-2">
                {quickPrompts.map((quickPrompt, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => handleQuickPrompt(quickPrompt)}
                    disabled={isLoading}
                    className="text-xs"
                  >
                    {quickPrompt}
                  </Button>
                ))}
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="flex gap-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isLoading}
                  className="flex-shrink-0"
                >
                  <Camera className="w-4 h-4 mr-2" />
                  Upload Image
                </Button>
                <Textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Ask LLaMA-4 Scout to analyze your image or any agricultural question..."
                  disabled={isLoading}
                  className="flex-1 min-h-[40px] max-h-[80px] resize-none"
                  rows={2}
                />
                <Button
                  type="submit"
                  disabled={isLoading || (!prompt.trim() && !selectedImage)}
                  className="bg-green-600 hover:bg-green-700 px-4 flex-shrink-0"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </form>
            <div className="text-xs text-gray-500 mt-2 flex items-center justify-between">
              <span>
                Powered by LLaMA-4 Scout for advanced agricultural vision analysis. Supports JPG, PNG, GIF up to 10MB.
              </span>
              {visionStatus === "unavailable" && (
                <Button variant="link" size="sm" onClick={switchToAssistant} className="text-xs p-0 h-auto">
                  Try Assistant Tab →
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
