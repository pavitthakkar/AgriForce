"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Grid3X3, Circle, Triangle } from "lucide-react"
import { useFarm, type FarmingSystemType } from "../contexts/farm-context"

export default function SystemSelector() {
  const { systemType, setSystemType } = useFarm()

  const systems = [
    {
      type: "vertical-rack" as FarmingSystemType,
      name: "Vertical Rack Farming",
      description: "Grid-based system with plants arranged in horizontal rows and vertical columns",
      icon: Grid3X3,
      features: ["Modular design", "Easy maintenance", "Scalable layout", "Efficient space usage"],
    },
    {
      type: "tower" as FarmingSystemType,
      name: "Tower Farming",
      description: "Cylindrical towers with plants arranged in circular levels around the structure",
      icon: Circle,
      features: ["360° plant access", "Vertical efficiency", "Central irrigation", "Compact footprint"],
    },
    {
      type: "a-frame" as FarmingSystemType,
      name: "A-Frame System",
      description: "Triangular structures with plants on both angled sides of the frame",
      icon: Triangle,
      features: ["Stable structure", "Dual-sided growing", "Natural drainage", "Space efficient"],
    },
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle>Choose Your Farming System</CardTitle>
        <p className="text-sm text-gray-600">
          Select the type of vertical farming system you want to design and manage.
        </p>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {systems.map((system) => {
            const Icon = system.icon
            const isSelected = systemType === system.type

            return (
              <div
                key={system.type}
                className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                  isSelected
                    ? "border-green-500 bg-green-50"
                    : "border-gray-200 hover:border-green-300 hover:bg-green-25"
                }`}
                onClick={() => setSystemType(system.type)}
              >
                <div className="text-center mb-3">
                  <Icon className={`w-12 h-12 mx-auto mb-2 ${isSelected ? "text-green-600" : "text-gray-400"}`} />
                  <h3 className={`font-semibold ${isSelected ? "text-green-800" : "text-gray-700"}`}>{system.name}</h3>
                </div>

                <p className="text-sm text-gray-600 mb-3 text-center">{system.description}</p>

                <ul className="text-xs space-y-1">
                  {system.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <div className={`w-1.5 h-1.5 rounded-full ${isSelected ? "bg-green-500" : "bg-gray-400"}`} />
                      <span className={isSelected ? "text-green-700" : "text-gray-600"}>{feature}</span>
                    </li>
                  ))}
                </ul>

                {isSelected && (
                  <div className="mt-3 text-center">
                    <span className="text-xs bg-green-600 text-white px-2 py-1 rounded-full">Selected</span>
                  </div>
                )}
              </div>
            )
          })}
        </div>

        <div className="mt-6 text-center">
          <Button
            onClick={() => {
              /* This will be handled by the parent component */
            }}
            className="bg-green-600 hover:bg-green-700"
            disabled={!systemType}
          >
            Continue with {systems.find((s) => s.type === systemType)?.name}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
