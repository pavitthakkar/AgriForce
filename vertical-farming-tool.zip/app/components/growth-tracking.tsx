"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useFarm } from "../contexts/farm-context"
import { useGrowth } from "../contexts/growth-context"
import { LineChart, Sprout, Calendar, Ruler, Plus, Leaf, ArrowUpRight, Clock, CheckCircle2 } from "lucide-react"

export default function GrowthTracking() {
  const { modules } = useFarm()
  const { growthData, addMeasurement, getModuleGrowthData, getGrowthStage, getGrowthRate, predictHarvest } = useGrowth()

  const [selectedModuleId, setSelectedModuleId] = useState<string | null>(null)
  const [newMeasurement, setNewMeasurement] = useState({
    height: 0,
    width: 0,
    leafCount: 0,
    stage: "seedling" as "seedling" | "vegetative" | "flowering" | "fruiting" | "mature",
  })

  const selectedModule = modules.find((m) => m.id === selectedModuleId)
  const selectedGrowthData = selectedModuleId ? getModuleGrowthData(selectedModuleId) : undefined
  const growthStage = selectedModuleId ? getGrowthStage(selectedModuleId) : undefined
  const growthRate = selectedModuleId ? getGrowthRate(selectedModuleId) : undefined
  const harvestDate = selectedModuleId ? predictHarvest(selectedModuleId) : undefined

  const handleAddMeasurement = () => {
    if (!selectedModuleId) return

    addMeasurement(selectedModuleId, newMeasurement)

    // Reset form
    setNewMeasurement({
      height: 0,
      width: 0,
      leafCount: 0,
      stage: "seedling",
    })
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString()
  }

  const getStageColor = (stage: string) => {
    switch (stage) {
      case "seedling":
        return "bg-blue-100 text-blue-800"
      case "vegetative":
        return "bg-green-100 text-green-800"
      case "flowering":
        return "bg-purple-100 text-purple-800"
      case "fruiting":
        return "bg-orange-100 text-orange-800"
      case "mature":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStageIcon = (stage: string) => {
    switch (stage) {
      case "seedling":
        return <Sprout className="w-4 h-4" />
      case "vegetative":
        return <Leaf className="w-4 h-4" />
      case "flowering":
        return <Sprout className="w-4 h-4" />
      case "fruiting":
        return <Sprout className="w-4 h-4" />
      case "mature":
        return <CheckCircle2 className="w-4 h-4" />
      default:
        return <Sprout className="w-4 h-4" />
    }
  }

  const getProgressPercentage = () => {
    if (!growthStage) return 0
    return Math.min(100, Math.round((growthStage.daysInStage / growthStage.expectedDuration) * 100))
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <LineChart className="w-5 h-5 text-green-600" />
          Growth Tracking
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div>
            <label className="text-sm font-medium mb-2 block">Select Plant Module</label>
            <Select value={selectedModuleId || ""} onValueChange={setSelectedModuleId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a plant module" />
              </SelectTrigger>
              <SelectContent>
                {modules.map((module) => (
                  <SelectItem key={module.id} value={module.id}>
                    {module.type} -
                    {module.tower !== undefined
                      ? ` Tower ${module.tower + 1}, Level ${module.level + 1}`
                      : module.frame !== undefined
                        ? ` Frame ${module.frame + 1}, Level ${module.level + 1}, ${module.side}`
                        : ` Row ${module.position.row + 1}, Col ${module.position.col + 1}`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedModule && (
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-3 mb-4">
                <TabsTrigger value="overview" className="flex items-center gap-2">
                  <LineChart className="w-4 h-4" />
                  Overview
                </TabsTrigger>
                <TabsTrigger value="measurements" className="flex items-center gap-2">
                  <Ruler className="w-4 h-4" />
                  Measurements
                </TabsTrigger>
                <TabsTrigger value="add" className="flex items-center gap-2">
                  <Plus className="w-4 h-4" />
                  Add Data
                </TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Plant info */}
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium mb-3">Plant Information</h3>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Type:</span>
                        <span className="font-medium">{selectedModule.type}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Planted:</span>
                        <span className="font-medium">{formatDate(selectedModule.plantedDate)}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Health:</span>
                        <span className="font-medium capitalize">{selectedModule.health}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Position:</span>
                        <span className="font-medium">
                          {selectedModule.tower !== undefined
                            ? `Tower ${selectedModule.tower + 1}, Level ${selectedModule.level + 1}`
                            : selectedModule.frame !== undefined
                              ? `Frame ${selectedModule.frame + 1}, Level ${selectedModule.level + 1}, ${selectedModule.side}`
                              : `Row ${selectedModule.position.row + 1}, Col ${selectedModule.position.col + 1}`}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Growth stage */}
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium mb-3">Growth Stage</h3>
                    {growthStage ? (
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <span
                            className={`px-2 py-1 rounded-full text-xs flex items-center gap-1 ${getStageColor(growthStage.stage)}`}
                          >
                            {getStageIcon(growthStage.stage)}
                            <span className="capitalize">{growthStage.stage}</span>
                          </span>

                          {growthStage.nextStage && (
                            <div className="flex items-center gap-1 text-xs text-gray-500">
                              <ArrowUpRight className="w-3 h-3" />
                              <span className="capitalize">{growthStage.nextStage}</span>
                            </div>
                          )}
                        </div>

                        <div className="space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span>Progress</span>
                            <span>
                              {growthStage.daysInStage} of {growthStage.expectedDuration} days
                            </span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-green-600 h-2 rounded-full"
                              style={{ width: `${getProgressPercentage()}%` }}
                            ></div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center gap-1 text-xs">
                            <Clock className="w-3 h-3 text-blue-500" />
                            <span>Growth rate:</span>
                          </div>
                          <span className="text-sm font-medium">
                            {growthRate !== undefined ? `${growthRate} cm/day` : "N/A"}
                          </span>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1 text-xs">
                            <Calendar className="w-3 h-3 text-blue-500" />
                            <span>Estimated harvest:</span>
                          </div>
                          <span className="text-sm font-medium">{harvestDate ? formatDate(harvestDate) : "N/A"}</span>
                        </div>
                      </div>
                    ) : (
                      <div className="text-sm text-gray-500">No growth data available</div>
                    )}
                  </div>
                </div>

                {/* Growth chart */}
                {selectedGrowthData && selectedGrowthData.measurements.length > 0 && (
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h3 className="text-sm font-medium mb-4">Growth Progress</h3>

                    <div className="h-64 relative">
                      <svg className="w-full h-full">
                        {/* Grid lines */}
                        <line x1="0" y1="200" x2="100%" y2="200" stroke="#e5e7eb" strokeWidth="1" />
                        <text x="5" y="195" fontSize="10" fill="#6b7280">
                          0 cm
                        </text>

                        <line x1="0" y1="150" x2="100%" y2="150" stroke="#e5e7eb" strokeWidth="1" />
                        <text x="5" y="145" fontSize="10" fill="#6b7280">
                          10 cm
                        </text>

                        <line x1="0" y1="100" x2="100%" y2="100" stroke="#e5e7eb" strokeWidth="1" />
                        <text x="5" y="95" fontSize="10" fill="#6b7280">
                          20 cm
                        </text>

                        <line x1="0" y1="50" x2="100%" y2="50" stroke="#e5e7eb" strokeWidth="1" />
                        <text x="5" y="45" fontSize="10" fill="#6b7280">
                          30 cm
                        </text>

                        <line x1="0" y1="0" x2="100%" y2="0" stroke="#e5e7eb" strokeWidth="1" />
                        <text x="5" y="15" fontSize="10" fill="#6b7280">
                          40 cm
                        </text>

                        {/* Height line */}
                        <polyline
                          points={selectedGrowthData.measurements
                            .map((measurement, index) => {
                              const x = (index / (selectedGrowthData.measurements.length - 1)) * 100 + "%"
                              // Map height to y coordinate (0-40cm range)
                              const y = 200 - (measurement.height / 40) * 200
                              return `${x},${y}`
                            })
                            .join(" ")}
                          fill="none"
                          stroke="#10b981"
                          strokeWidth="2"
                        />

                        {/* Data points */}
                        {selectedGrowthData.measurements.map((measurement, index) => {
                          const x = (index / (selectedGrowthData.measurements.length - 1)) * 100 + "%"
                          const y = 200 - (measurement.height / 40) * 200
                          return <circle key={index} cx={x} cy={y} r="3" fill="#10b981" />
                        })}
                      </svg>

                      <div className="absolute bottom-0 left-0 right-0 flex justify-between text-xs text-gray-500">
                        <span>{formatDate(selectedGrowthData.measurements[0]?.date || new Date().toISOString())}</span>
                        <span>
                          {formatDate(
                            selectedGrowthData.measurements[selectedGrowthData.measurements.length - 1]?.date ||
                              new Date().toISOString(),
                          )}
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="measurements" className="space-y-4">
                {selectedGrowthData && selectedGrowthData.measurements.length > 0 ? (
                  <div className="space-y-4">
                    <h3 className="text-sm font-medium">Measurement History</h3>
                    <div className="space-y-2 max-h-96 overflow-y-auto">
                      {selectedGrowthData.measurements
                        .slice()
                        .reverse()
                        .map((measurement, index) => (
                          <div key={index} className="bg-gray-50 p-3 rounded-lg">
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-sm font-medium">{formatDate(measurement.date)}</span>
                              <span
                                className={`px-2 py-1 rounded-full text-xs flex items-center gap-1 ${getStageColor(measurement.stage)}`}
                              >
                                {getStageIcon(measurement.stage)}
                                <span className="capitalize">{measurement.stage}</span>
                              </span>
                            </div>
                            <div className="grid grid-cols-3 gap-4 text-sm">
                              <div>
                                <span className="text-gray-600">Height:</span>
                                <span className="font-medium ml-1">{measurement.height} cm</span>
                              </div>
                              <div>
                                <span className="text-gray-600">Width:</span>
                                <span className="font-medium ml-1">{measurement.width} cm</span>
                              </div>
                              <div>
                                <span className="text-gray-600">Leaves:</span>
                                <span className="font-medium ml-1">{measurement.leafCount}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    <Ruler className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                    <p>No measurements recorded yet</p>
                    <p className="text-sm">Add your first measurement to start tracking growth</p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="add" className="space-y-4">
                <h3 className="text-sm font-medium">Add New Measurement</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="height" className="text-sm font-medium">
                        Height (cm)
                      </Label>
                      <Input
                        id="height"
                        type="number"
                        step="0.1"
                        value={newMeasurement.height}
                        onChange={(e) =>
                          setNewMeasurement((prev) => ({ ...prev, height: Number.parseFloat(e.target.value) || 0 }))
                        }
                        placeholder="Enter height in cm"
                      />
                    </div>

                    <div>
                      <Label htmlFor="width" className="text-sm font-medium">
                        Width (cm)
                      </Label>
                      <Input
                        id="width"
                        type="number"
                        step="0.1"
                        value={newMeasurement.width}
                        onChange={(e) =>
                          setNewMeasurement((prev) => ({ ...prev, width: Number.parseFloat(e.target.value) || 0 }))
                        }
                        placeholder="Enter width in cm"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="leafCount" className="text-sm font-medium">
                        Leaf Count
                      </Label>
                      <Input
                        id="leafCount"
                        type="number"
                        value={newMeasurement.leafCount}
                        onChange={(e) =>
                          setNewMeasurement((prev) => ({ ...prev, leafCount: Number.parseInt(e.target.value) || 0 }))
                        }
                        placeholder="Count visible leaves"
                      />
                    </div>

                    <div>
                      <Label htmlFor="stage" className="text-sm font-medium">
                        Growth Stage
                      </Label>
                      <Select
                        value={newMeasurement.stage}
                        onValueChange={(value: "seedling" | "vegetative" | "flowering" | "fruiting" | "mature") =>
                          setNewMeasurement((prev) => ({ ...prev, stage: value }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="seedling">Seedling</SelectItem>
                          <SelectItem value="vegetative">Vegetative</SelectItem>
                          <SelectItem value="flowering">Flowering</SelectItem>
                          <SelectItem value="fruiting">Fruiting</SelectItem>
                          <SelectItem value="mature">Mature</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <Button
                  onClick={handleAddMeasurement}
                  className="bg-green-600 hover:bg-green-700 w-full"
                  disabled={newMeasurement.height === 0}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Measurement
                </Button>
              </TabsContent>
            </Tabs>
          )}

          {!selectedModule && (
            <div className="text-center text-gray-500 py-8">
              <LineChart className="w-12 h-12 mx-auto mb-4 text-gray-400" />
              <p>Select a plant module to view growth tracking</p>
              <p className="text-sm">Choose from your planted modules above</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
