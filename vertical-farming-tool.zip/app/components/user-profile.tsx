"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useAuth } from "@/app/contexts/auth-context"
import { Loader2, User } from "lucide-react"

export default function UserProfile() {
  const { user, updateProfile, signOut, isLoading } = useAuth()
  const [fullName, setFullName] = useState(user?.fullName || "")
  const [isEditing, setIsEditing] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await updateProfile({ fullName })
    setIsEditing(false)
  }

  if (!user) {
    return null
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl flex items-center gap-2">
          <User className="h-6 w-6 text-green-600" />
          User Profile
        </CardTitle>
        <CardDescription>Manage your account information</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Email</Label>
          <div className="p-2 bg-gray-50 rounded-md">{user.email}</div>
        </div>

        {isEditing ? (
          <form onSubmit={handleSubmit}>
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input id="fullName" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
            </div>
            <div className="flex gap-2 mt-4">
              <Button type="submit" className="bg-green-600 hover:bg-green-700" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setFullName(user.fullName || "")
                  setIsEditing(false)
                }}
              >
                Cancel
              </Button>
            </div>
          </form>
        ) : (
          <div className="space-y-2">
            <Label>Full Name</Label>
            <div className="p-2 bg-gray-50 rounded-md">{user.fullName || "Not set"}</div>
            <Button variant="outline" size="sm" onClick={() => setIsEditing(true)} className="mt-2">
              Edit Profile
            </Button>
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button variant="destructive" onClick={signOut} disabled={isLoading} className="w-full">
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Processing...
            </>
          ) : (
            "Sign Out"
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}
