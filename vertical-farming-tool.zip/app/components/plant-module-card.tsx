"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Trash2, Plus, Sprout } from "lucide-react"
import { useFarm, type PlantModule } from "../contexts/farm-context"

interface PlantModuleCardProps {
  module: PlantModule
  isOpen?: boolean
  onClose?: () => void
}

const healthColors = {
  excellent: "bg-green-500",
  good: "bg-green-400",
  fair: "bg-yellow-400",
  poor: "bg-red-400",
}

export default function PlantModuleCard({ module, isOpen: externalIsOpen, onClose }: PlantModuleCardProps) {
  const { removeModule, updateModule, addNote } = useFarm()
  const [newNote, setNewNote] = useState("")
  const [internalIsOpen, setInternalIsOpen] = useState(false)

  // Use external control if provided, otherwise use internal state
  const isOpen = externalIsOpen !== undefined ? externalIsOpen : internalIsOpen
  const setIsOpen = onClose ? onClose : setInternalIsOpen

  const handleAddNote = () => {
    if (newNote.trim()) {
      addNote(module.id, newNote.trim())
      setNewNote("")
    }
  }

  const handleHealthChange = (health: PlantModule["health"]) => {
    updateModule(module.id, { health })
  }

  const daysSincePlanted = Math.floor(
    (new Date().getTime() - new Date(module.plantedDate).getTime()) / (1000 * 60 * 60 * 24),
  )

  // If being used with external control, don't render the trigger
  if (externalIsOpen !== undefined) {
    return (
      <Dialog open={isOpen} onOpenChange={(open) => !open && onClose?.()}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sprout className="w-5 h-5 text-green-600" />
              {module.type} Module
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="font-medium">Planted:</span> {module.plantedDate}
              </div>
              <div>
                <span className="font-medium">Days:</span> {daysSincePlanted}
              </div>
              <div>
                <span className="font-medium">Position:</span>
                {module.tower !== undefined
                  ? ` Tower ${module.tower + 1}, Level ${module.level + 1}`
                  : module.frame !== undefined
                    ? ` Frame ${module.frame + 1}, Level ${module.level + 1}, ${module.side}`
                    : ` Row ${module.position.row + 1}, Col ${module.position.col + 1}`}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Health Status</label>
              <Select value={module.health} onValueChange={handleHealthChange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="excellent">Excellent</SelectItem>
                  <SelectItem value="good">Good</SelectItem>
                  <SelectItem value="fair">Fair</SelectItem>
                  <SelectItem value="poor">Poor</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Daily Notes</label>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {module.notes.length === 0 ? (
                  <p className="text-sm text-gray-500">No notes yet</p>
                ) : (
                  module.notes.slice(-5).map((note) => (
                    <div key={note.id} className="text-sm p-2 bg-gray-50 rounded">
                      <div className="font-medium text-xs text-gray-600">{note.date}</div>
                      <div>{note.note}</div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Add Note</label>
              <div className="flex gap-2">
                <Textarea
                  value={newNote}
                  onChange={(e) => setNewNote(e.target.value)}
                  placeholder="Add a daily observation..."
                  className="flex-1"
                  rows={2}
                />
                <Button onClick={handleAddNote} size="sm" className="bg-green-600 hover:bg-green-700">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="flex justify-between pt-4">
              <Button
                variant="destructive"
                size="sm"
                onClick={() => {
                  removeModule(module.id)
                  onClose?.()
                }}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Remove
              </Button>
              <Button onClick={() => onClose?.()}>Close</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Original trigger-based implementation for grid system
  return (
    <Dialog open={internalIsOpen} onOpenChange={setInternalIsOpen}>
      <DialogTrigger asChild>
        <div className="w-full h-full cursor-pointer">
          <Card className="w-full h-full hover:shadow-md transition-shadow">
            <CardContent className="p-2 h-full flex flex-col justify-between">
              <div className="text-center">
                <Sprout className="w-6 h-6 mx-auto text-green-600 mb-1" />
                <div className="text-xs font-medium truncate">{module.type}</div>
                <div className={`w-3 h-3 rounded-full mx-auto mt-1 ${healthColors[module.health]}`} />
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogTrigger>

      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sprout className="w-5 h-5 text-green-600" />
            {module.type} Module
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="font-medium">Planted:</span> {module.plantedDate}
            </div>
            <div>
              <span className="font-medium">Days:</span> {daysSincePlanted}
            </div>
            <div>
              <span className="font-medium">Position:</span> Row {module.position.row + 1}, Col{" "}
              {module.position.col + 1}
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Health Status</label>
            <Select value={module.health} onValueChange={handleHealthChange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="excellent">Excellent</SelectItem>
                <SelectItem value="good">Good</SelectItem>
                <SelectItem value="fair">Fair</SelectItem>
                <SelectItem value="poor">Poor</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Daily Notes</label>
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {module.notes.length === 0 ? (
                <p className="text-sm text-gray-500">No notes yet</p>
              ) : (
                module.notes.slice(-5).map((note) => (
                  <div key={note.id} className="text-sm p-2 bg-gray-50 rounded">
                    <div className="font-medium text-xs text-gray-600">{note.date}</div>
                    <div>{note.note}</div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Add Note</label>
            <div className="flex gap-2">
              <Textarea
                value={newNote}
                onChange={(e) => setNewNote(e.target.value)}
                placeholder="Add a daily observation..."
                className="flex-1"
                rows={2}
              />
              <Button onClick={handleAddNote} size="sm" className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="flex justify-between pt-4">
            <Button
              variant="destructive"
              size="sm"
              onClick={() => {
                removeModule(module.id)
                setIsOpen(false)
              }}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Remove
            </Button>
            <Button onClick={() => setIsOpen(false)}>Close</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
