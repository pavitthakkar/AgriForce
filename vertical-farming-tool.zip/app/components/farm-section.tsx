"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Grid3X3, MoveHorizontal, MoveVertical, Lightbulb, Droplets } from "lucide-react"
import { useFarm } from "../contexts/farm-context"
import PlantModuleCard from "./plant-module-card"
import { Label } from "@/components/ui/label"

const PLANT_TYPES = ["Lettuce", "Spinach", "Kale", "Basil", "Cilantro", "Arugula", "Swiss Chard", "Bok Choy"]

const LIGHTING_TYPES = [
  { value: "LED", label: "LED (Light Emitting Diode)", efficiency: "High", lifespan: "50,000+ hours" },
  { value: "Fluorescent", label: "Fluorescent", efficiency: "Medium", lifespan: "10,000-15,000 hours" },
  { value: "Incandescent", label: "Incandescent", efficiency: "Low", lifespan: "1,000 hours" },
  { value: "HPS", label: "High Pressure Sodium", efficiency: "Medium-High", lifespan: "24,000 hours" },
  { value: "CMH", label: "Ceramic Metal Halide", efficiency: "High", lifespan: "20,000 hours" },
  { value: "T5", label: "T5 Fluorescent", efficiency: "Medium-High", lifespan: "20,000 hours" },
  { value: "CFL", label: "Compact Fluorescent", efficiency: "Medium", lifespan: "8,000-15,000 hours" },
] as const

export default function FarmSection() {
  const { modules, lighting, irrigation, addModule, addLighting, addIrrigationPipe, farmSize, updateFarmSize } =
    useFarm()
  const [selectedPlant, setSelectedPlant] = useState("")
  const [selectedPosition, setSelectedPosition] = useState<{ row: number; col: number } | null>(null)
  const [pipeStart, setPipeStart] = useState<{ row: number; col: number } | null>(null)
  const [pipeEnd, setPipeEnd] = useState<{ row: number; col: number } | null>(null)
  const [pipeType, setPipeType] = useState<"main" | "branch">("main")
  const [selectedLightingType, setSelectedLightingType] = useState<
    "LED" | "Fluorescent" | "Incandescent" | "HPS" | "CMH" | "T5" | "CFL"
  >("LED")

  const handleAddModule = () => {
    if (!selectedPlant || !selectedPosition) return

    const success = addModule({
      type: selectedPlant,
      plantedDate: new Date().toISOString().split("T")[0],
      health: "good",
      notes: [],
      position: selectedPosition,
    })

    if (!success) {
      alert("This position is already occupied by another plant.")
      return
    }

    setSelectedPlant("")
    setSelectedPosition(null)
  }

  const handleAddLighting = () => {
    if (!selectedPosition) return

    const success = addLighting({
      position: selectedPosition,
      intensity: 80,
      coverage: 1,
      type: selectedLightingType,
    })

    if (!success) {
      alert("Lighting already exists at this position.")
      return
    }

    setSelectedPosition(null)
    setSelectedLightingType("LED")
  }

  const handleAddPipe = () => {
    if (!pipeStart || !pipeEnd) return

    addIrrigationPipe({
      from: pipeStart,
      to: pipeEnd,
      type: pipeType,
    })

    setPipeStart(null)
    setPipeEnd(null)
  }

  const handleRowsChange = (value: number[]) => {
    updateFarmSize({ rows: value[0], cols: farmSize.cols })
  }

  const handleColsChange = (value: number[]) => {
    updateFarmSize({ rows: farmSize.rows, cols: value[0] })
  }

  const getAvailablePositionsForPlants = () => {
    const occupied = new Set(modules.map((m) => `${m.position.row}-${m.position.col}`))
    const available = []

    for (let row = 0; row < farmSize.rows; row++) {
      for (let col = 0; col < farmSize.cols; col++) {
        if (!occupied.has(`${row}-${col}`)) {
          available.push({ row, col })
        }
      }
    }
    return available
  }

  const getAllPositions = () => {
    const positions = []
    for (let row = 0; row < farmSize.rows; row++) {
      for (let col = 0; col < farmSize.cols; col++) {
        positions.push({ row, col })
      }
    }
    return positions
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Grid3X3 className="w-5 h-5" />
            Farm Layout
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="plants" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-4">
              <TabsTrigger value="plants" className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Add Plants
              </TabsTrigger>
              <TabsTrigger value="lighting" className="flex items-center gap-2">
                <Lightbulb className="w-4 h-4" />
                Add Lighting
              </TabsTrigger>
              <TabsTrigger value="irrigation" className="flex items-center gap-2">
                <Droplets className="w-4 h-4" />
                Add Irrigation
              </TabsTrigger>
            </TabsList>

            <TabsContent value="plants" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-sm font-medium mb-2 block">Plant Type</Label>
                  <Select value={selectedPlant} onValueChange={setSelectedPlant}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select plant type" />
                    </SelectTrigger>
                    <SelectContent>
                      {PLANT_TYPES.map((plant) => (
                        <SelectItem key={plant} value={plant}>
                          {plant}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">Position</Label>
                  <Select
                    value={selectedPosition ? `${selectedPosition.row}-${selectedPosition.col}` : ""}
                    onValueChange={(value) => {
                      const [row, col] = value.split("-").map(Number)
                      setSelectedPosition({ row, col })
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select position" />
                    </SelectTrigger>
                    <SelectContent>
                      {getAvailablePositionsForPlants().map((pos) => (
                        <SelectItem key={`${pos.row}-${pos.col}`} value={`${pos.row}-${pos.col}`}>
                          Row {pos.row + 1}, Col {pos.col + 1}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-end">
                  <Button
                    onClick={handleAddModule}
                    disabled={!selectedPlant || !selectedPosition}
                    className="bg-green-600 hover:bg-green-700 w-full"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Plant Module
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="lighting" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-sm font-medium mb-2 block">Lighting Type</Label>
                  <Select value={selectedLightingType} onValueChange={(value: any) => setSelectedLightingType(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {LIGHTING_TYPES.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          <div className="flex flex-col">
                            <span>{type.label}</span>
                            <span className="text-xs text-gray-500">
                              Efficiency: {type.efficiency} | Life: {type.lifespan}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">Position (Above Plants)</Label>
                  <Select
                    value={selectedPosition ? `${selectedPosition.row}-${selectedPosition.col}` : ""}
                    onValueChange={(value) => {
                      const [row, col] = value.split("-").map(Number)
                      setSelectedPosition({ row, col })
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select position" />
                    </SelectTrigger>
                    <SelectContent>
                      {getAllPositions().map((pos) => (
                        <SelectItem key={`${pos.row}-${pos.col}`} value={`${pos.row}-${pos.col}`}>
                          Row {pos.row + 1}, Col {pos.col + 1}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-end">
                  <Button
                    onClick={handleAddLighting}
                    disabled={!selectedPosition}
                    className="bg-yellow-600 hover:bg-yellow-700 w-full"
                  >
                    <Lightbulb className="w-4 h-4 mr-2" />
                    Add {selectedLightingType} Lighting
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="irrigation" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <Label className="text-sm font-medium mb-2 block">Pipe Type</Label>
                  <Select value={pipeType} onValueChange={(value: "main" | "branch") => setPipeType(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="main">Main Pipe (Thick)</SelectItem>
                      <SelectItem value="branch">Branch Pipe (Thin)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">From Position</Label>
                  <Select
                    value={pipeStart ? `${pipeStart.row}-${pipeStart.col}` : ""}
                    onValueChange={(value) => {
                      const [row, col] = value.split("-").map(Number)
                      setPipeStart({ row, col })
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Start position" />
                    </SelectTrigger>
                    <SelectContent>
                      {getAllPositions().map((pos) => (
                        <SelectItem key={`${pos.row}-${pos.col}`} value={`${pos.row}-${pos.col}`}>
                          Row {pos.row + 1}, Col {pos.col + 1}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">To Position</Label>
                  <Select
                    value={pipeEnd ? `${pipeEnd.row}-${pipeEnd.col}` : ""}
                    onValueChange={(value) => {
                      const [row, col] = value.split("-").map(Number)
                      setPipeEnd({ row, col })
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="End position" />
                    </SelectTrigger>
                    <SelectContent>
                      {getAllPositions().map((pos) => (
                        <SelectItem key={`${pos.row}-${pos.col}`} value={`${pos.row}-${pos.col}`}>
                          Row {pos.row + 1}, Col {pos.col + 1}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-end">
                  <Button
                    onClick={handleAddPipe}
                    disabled={!pipeStart || !pipeEnd}
                    className="bg-blue-600 hover:bg-blue-700 w-full"
                  >
                    <Droplets className="w-4 h-4 mr-2" />
                    Add Pipe
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <div className="mt-6 space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="flex items-center gap-2">
                  <MoveVertical className="w-4 h-4" />
                  Rows: {farmSize.rows}
                </Label>
              </div>
              <Slider
                value={[farmSize.rows]}
                min={1}
                max={10}
                step={1}
                onValueChange={handleRowsChange}
                className="w-full"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="flex items-center gap-2">
                  <MoveHorizontal className="w-4 h-4" />
                  Columns: {farmSize.cols}
                </Label>
              </div>
              <Slider
                value={[farmSize.cols]}
                min={1}
                max={12}
                step={1}
                onValueChange={handleColsChange}
                className="w-full"
              />
            </div>
          </div>

          <FarmGrid />

          <div className="mt-4 flex justify-between text-sm">
            <div className="text-green-600">Plants: {modules.length}</div>
            <div className="text-yellow-600">
              Lighting: {lighting.length} systems
              {lighting.length > 0 && (
                <span className="text-xs ml-1">
                  (
                  {Object.entries(
                    lighting.reduce(
                      (acc, l) => {
                        acc[l.type] = (acc[l.type] || 0) + 1
                        return acc
                      },
                      {} as Record<string, number>,
                    ),
                  )
                    .map(([type, count]) => `${count} ${type}`)
                    .join(", ")}
                  )
                </span>
              )}
            </div>
            <div className="text-blue-600">Irrigation: {irrigation.length} pipes</div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function FarmGrid() {
  const { modules, lighting, irrigation, farmSize } = useFarm()

  // Create grid layout
  const grid = Array(farmSize.rows)
    .fill(null)
    .map(() => Array(farmSize.cols).fill(null))

  // Place modules
  modules.forEach((module) => {
    if (module.position.row < farmSize.rows && module.position.col < farmSize.cols) {
      grid[module.position.row][module.position.col] = module
    }
  })

  // Helper function to check if a position has lighting
  const hasLighting = (row: number, col: number) => {
    return lighting.some((l) => l.position.row === row && l.position.col === col)
  }

  // Helper function to get irrigation connections for a cell
  const getIrrigationConnections = (row: number, col: number) => {
    return irrigation.filter(
      (pipe) => (pipe.from.row === row && pipe.from.col === col) || (pipe.to.row === row && pipe.to.col === col),
    )
  }

  // Helper function to get pipe pair numbers for a cell
  const getPipePairNumbers = (row: number, col: number) => {
    const connections = getIrrigationConnections(row, col)

    // Create a mapping of pipe IDs to pair numbers (1, 2, 3, etc.)
    const pipeNumbers = irrigation.map((pipe, index) => ({
      id: pipe.id,
      pairNumber: index + 1,
    }))

    // Get the pair numbers for this cell's connections
    const cellPairNumbers = connections
      .map((pipe) => {
        const pipeInfo = pipeNumbers.find((p) => p.id === pipe.id)
        return pipeInfo ? pipeInfo.pairNumber : 0
      })
      .sort((a, b) => a - b)

    return cellPairNumbers
  }

  // Helper function to get connection direction indicators
  const getConnectionIndicators = (row: number, col: number) => {
    const connections = getIrrigationConnections(row, col)
    const indicators = []

    connections.forEach((pipe) => {
      const isSource = pipe.from.row === row && pipe.from.col === col
      const otherPos = isSource ? pipe.to : pipe.from

      // Determine direction
      const deltaRow = otherPos.row - row
      const deltaCol = otherPos.col - col

      let direction = ""
      if (deltaRow === 0 && deltaCol > 0) direction = "right"
      else if (deltaRow === 0 && deltaCol < 0) direction = "left"
      else if (deltaRow > 0 && deltaCol === 0) direction = "bottom"
      else if (deltaRow < 0 && deltaCol === 0) direction = "top"
      else if (deltaRow > 0 && deltaCol > 0) direction = "bottom-right"
      else if (deltaRow > 0 && deltaCol < 0) direction = "bottom-left"
      else if (deltaRow < 0 && deltaCol > 0) direction = "top-right"
      else if (deltaRow < 0 && deltaCol < 0) direction = "top-left"

      indicators.push({
        direction,
        type: pipe.type,
        isSource,
      })
    })

    return indicators
  }

  return (
    <div className="relative">
      {/* Simple dotted line connections with pair numbers */}
      <svg
        className="absolute inset-0 pointer-events-none z-10"
        style={{
          width: `${farmSize.cols * 88}px`,
          height: `${farmSize.rows * 88}px`,
        }}
      >
        {irrigation.map((pipe, index) => {
          const cellSize = 80
          const gap = 8
          const totalCellSize = cellSize + gap
          const pairNumber = index + 1

          const fromX = pipe.from.col * totalCellSize + cellSize / 2
          const fromY = pipe.from.row * totalCellSize + cellSize / 2
          const toX = pipe.to.col * totalCellSize + cellSize / 2
          const toY = pipe.to.row * totalCellSize + cellSize / 2

          // Calculate midpoint for label
          const midX = (fromX + toX) / 2
          const midY = (fromY + toY) / 2

          return (
            <g key={pipe.id}>
              <line
                x1={fromX}
                y1={fromY}
                x2={toX}
                y2={toY}
                stroke="#4d79ff"
                strokeWidth={pipe.type === "main" ? 3 : 2}
                strokeDasharray={pipe.type === "main" ? "8,4" : "4,2"}
                opacity="0.8"
              />
              {/* Pair number label on the line */}
              <circle cx={midX} cy={midY} r="8" fill="#4d79ff" stroke="white" strokeWidth="2" />
              <text
                x={midX}
                y={midY}
                textAnchor="middle"
                dominantBaseline="central"
                fill="white"
                fontSize="10"
                fontWeight="bold"
              >
                {pairNumber}
              </text>
            </g>
          )
        })}
      </svg>

      {/* Grid */}
      <div
        className="grid gap-2 p-4 bg-green-50 rounded-lg border-2 border-green-200 overflow-x-auto relative z-20"
        style={{
          gridTemplateColumns: `repeat(${farmSize.cols}, minmax(80px, 1fr))`,
          gridTemplateRows: `repeat(${farmSize.rows}, minmax(80px, 1fr))`,
        }}
      >
        {grid.map((row, rowIndex) =>
          row.map((module, colIndex) => {
            const hasLight = hasLighting(rowIndex, colIndex)
            const connections = getIrrigationConnections(rowIndex, colIndex)
            const pairNumbers = getPipePairNumbers(rowIndex, colIndex)
            const indicators = getConnectionIndicators(rowIndex, colIndex)
            const isEmpty = !module

            return (
              <div
                key={`${rowIndex}-${colIndex}`}
                className={`aspect-square border-2 rounded-lg flex items-center justify-center min-h-[80px] min-w-[80px] relative ${
                  isEmpty ? "border-dashed border-green-300" : "border-solid border-green-400"
                } ${connections.length > 0 ? "ring-2 ring-blue-200 ring-opacity-50" : ""}`}
              >
                {/* Plant module */}
                {module && <PlantModuleCard module={module} />}

                {/* Lighting indicator */}
                {hasLight && (
                  <div className="absolute -top-2 -right-2 z-40">
                    <div className="bg-yellow-400 rounded-full p-2 shadow-lg border-2 border-yellow-300">
                      <Lightbulb className="w-6 h-6 text-yellow-800" fill="currentColor" />
                      <div className="absolute -bottom-1 -right-1 bg-blue-600 text-white text-xs px-1 rounded">
                        {lighting
                          .find((l) => l.position.row === rowIndex && l.position.col === colIndex)
                          ?.type.slice(0, 3)}
                      </div>
                    </div>
                  </div>
                )}

                {/* Irrigation connection indicators with pair numbers */}
                {connections.length > 0 && (
                  <div className="absolute bottom-1 left-1 z-30">
                    <div className="bg-blue-500 rounded-lg px-2 py-1 shadow-sm flex items-center gap-1">
                      <Droplets className="w-3 h-3 text-white" />
                      <span className="text-white text-xs font-bold">{pairNumbers.join(",")}</span>
                    </div>
                  </div>
                )}

                {/* Direction indicators on cell borders */}
                {indicators.map((indicator, index) => {
                  const positionClasses = {
                    top: "absolute -top-1 left-1/2 transform -translate-x-1/2",
                    bottom: "absolute -bottom-1 left-1/2 transform -translate-x-1/2",
                    left: "absolute top-1/2 -left-1 transform -translate-y-1/2",
                    right: "absolute top-1/2 -right-1 transform -translate-y-1/2",
                    "top-left": "absolute -top-1 -left-1",
                    "top-right": "absolute -top-1 -right-1",
                    "bottom-left": "absolute -bottom-1 -left-1",
                    "bottom-right": "absolute -bottom-1 -right-1",
                  }

                  return (
                    <div key={index} className={`${positionClasses[indicator.direction]} z-30`}>
                      <div
                        className={`w-2 h-2 rounded-full ${
                          indicator.type === "main" ? "bg-blue-600" : "bg-blue-400"
                        } border border-white shadow-sm`}
                      />
                    </div>
                  )
                })}

                {/* Empty cell indicator */}
                {isEmpty && (
                  <div className="text-green-400 text-xs text-center">
                    R{rowIndex + 1}C{colIndex + 1}
                  </div>
                )}
              </div>
            )
          }),
        )}
      </div>
    </div>
  )
}
