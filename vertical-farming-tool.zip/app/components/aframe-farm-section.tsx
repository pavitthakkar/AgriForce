"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Triangle, Lightbulb, Droplets } from "lucide-react"
import { useFarm } from "../contexts/farm-context"
import { Label } from "@/components/ui/label"
import PlantModuleCard from "./plant-module-card"

const PLANT_TYPES = ["Lettuce", "Spinach", "Kale", "Basil", "Cilantro", "Arugula", "Swiss Chard", "Bok Choy"]

const LIGHTING_TYPES = [
  { value: "LED", label: "LED (Light Emitting Diode)", efficiency: "High", lifespan: "50,000+ hours" },
  { value: "Fluorescent", label: "Fluorescent", efficiency: "Medium", lifespan: "10,000-15,000 hours" },
  { value: "Incandescent", label: "Incandescent", efficiency: "Low", lifespan: "1,000 hours" },
  { value: "HPS", label: "High Pressure Sodium", efficiency: "Medium-High", lifespan: "24,000 hours" },
  { value: "CMH", label: "Ceramic Metal Halide", efficiency: "High", lifespan: "20,000 hours" },
  { value: "T5", label: "T5 Fluorescent", efficiency: "Medium-High", lifespan: "20,000 hours" },
  { value: "CFL", label: "Compact Fluorescent", efficiency: "Medium", lifespan: "8,000-15,000 hours" },
] as const

export default function AFrameFarmSection() {
  const { modules, lighting, irrigation, addModule, addLighting, addIrrigationPipe, farmSize, updateFarmSize } =
    useFarm()
  const [selectedPlant, setSelectedPlant] = useState("")
  const [selectedFrame, setSelectedFrame] = useState<number | null>(null)
  const [selectedLevel, setSelectedLevel] = useState<number | null>(null)
  const [selectedSide, setSelectedSide] = useState<"left" | "right" | null>(null)
  const [selectedPlantForDialog, setSelectedPlantForDialog] = useState<string | null>(null)
  const [selectedLightingType, setSelectedLightingType] = useState<
    "LED" | "Fluorescent" | "Incandescent" | "HPS" | "CMH" | "T5" | "CFL"
  >("LED")

  const handleAddModule = () => {
    if (!selectedPlant || selectedFrame === null || selectedLevel === null || !selectedSide) return

    const success = addModule({
      type: selectedPlant,
      plantedDate: new Date().toISOString().split("T")[0],
      health: "good",
      notes: [],
      position: { row: 0, col: 0 }, // Not used for A-frame farming
      frame: selectedFrame,
      level: selectedLevel,
      side: selectedSide,
    })

    if (!success) {
      alert("This position is already occupied by another plant.")
      return
    }

    setSelectedPlant("")
    setSelectedFrame(null)
    setSelectedLevel(null)
    setSelectedSide(null)
  }

  const handleAddLighting = () => {
    if (selectedFrame === null) return

    const success = addLighting({
      position: { row: 0, col: 0 }, // Not used for A-frame farming
      intensity: 80,
      coverage: 1,
      type: selectedLightingType,
      frame: selectedFrame,
    })

    if (!success) {
      alert("Lighting already exists for this A-frame.")
      return
    }

    setSelectedFrame(null)
    setSelectedLightingType("LED")
  }

  const handleFramesChange = (value: number[]) => {
    updateFarmSize({ ...farmSize, frames: value[0] })
  }

  const handleLevelsChange = (value: number[]) => {
    updateFarmSize({ ...farmSize, levelsPerFrame: value[0] })
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Triangle className="w-5 h-5" />
            A-Frame Farm Layout
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="plants" className="w-full">
            <TabsList className="grid w-full grid-cols-3 mb-4">
              <TabsTrigger value="plants" className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                Add Plants
              </TabsTrigger>
              <TabsTrigger value="lighting" className="flex items-center gap-2">
                <Lightbulb className="w-4 h-4" />
                Add Lighting
              </TabsTrigger>
              <TabsTrigger value="irrigation" className="flex items-center gap-2">
                <Droplets className="w-4 h-4" />
                Add Irrigation
              </TabsTrigger>
            </TabsList>

            <TabsContent value="plants" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                <div>
                  <Label className="text-sm font-medium mb-2 block">Plant Type</Label>
                  <Select value={selectedPlant} onValueChange={setSelectedPlant}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select plant type" />
                    </SelectTrigger>
                    <SelectContent>
                      {PLANT_TYPES.map((plant) => (
                        <SelectItem key={plant} value={plant}>
                          {plant}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">A-Frame</Label>
                  <Select
                    value={selectedFrame?.toString() || ""}
                    onValueChange={(value) => setSelectedFrame(Number.parseInt(value))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select frame" />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: farmSize.frames || 3 }, (_, i) => (
                        <SelectItem key={i} value={i.toString()}>
                          Frame {i + 1}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">Level</Label>
                  <Select
                    value={selectedLevel?.toString() || ""}
                    onValueChange={(value) => setSelectedLevel(Number.parseInt(value))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select level" />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: farmSize.levelsPerFrame || 5 }, (_, i) => (
                        <SelectItem key={i} value={i.toString()}>
                          Level {i + 1}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">Side</Label>
                  <Select
                    value={selectedSide || ""}
                    onValueChange={(value: "left" | "right") => setSelectedSide(value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select side" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="left">Left Side</SelectItem>
                      <SelectItem value="right">Right Side</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-end">
                  <Button
                    onClick={handleAddModule}
                    disabled={!selectedPlant || selectedFrame === null || selectedLevel === null || !selectedSide}
                    className="bg-green-600 hover:bg-green-700 w-full"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Plant Module
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="lighting" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-sm font-medium mb-2 block">Lighting Type</Label>
                  <Select value={selectedLightingType} onValueChange={(value: any) => setSelectedLightingType(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {LIGHTING_TYPES.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          <div className="flex flex-col">
                            <span>{type.label}</span>
                            <span className="text-xs text-gray-500">
                              Efficiency: {type.efficiency} | Life: {type.lifespan}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">A-Frame</Label>
                  <Select
                    value={selectedFrame?.toString() || ""}
                    onValueChange={(value) => setSelectedFrame(Number.parseInt(value))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select frame" />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({ length: farmSize.frames || 3 }, (_, i) => (
                        <SelectItem key={i} value={i.toString()}>
                          Frame {i + 1}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-end">
                  <Button
                    onClick={handleAddLighting}
                    disabled={selectedFrame === null}
                    className="bg-yellow-600 hover:bg-yellow-700 w-full"
                  >
                    <Lightbulb className="w-4 h-4 mr-2" />
                    Add {selectedLightingType} Lighting
                  </Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="irrigation" className="space-y-4">
              <div className="text-center text-gray-500 py-8">
                <Droplets className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p>A-Frame irrigation system coming soon...</p>
                <p className="text-sm">A-Frames typically use gravity-fed drip irrigation</p>
              </div>
            </TabsContent>
          </Tabs>

          <div className="mt-6 space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="flex items-center gap-2">
                  <Triangle className="w-4 h-4" />
                  Number of A-Frames: {farmSize.frames || 3}
                </Label>
              </div>
              <Slider
                value={[farmSize.frames || 3]}
                min={1}
                max={6}
                step={1}
                onValueChange={handleFramesChange}
                className="w-full"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="flex items-center gap-2">
                  <Triangle className="w-4 h-4" />
                  Levels per Frame: {farmSize.levelsPerFrame || 5}
                </Label>
              </div>
              <Slider
                value={[farmSize.levelsPerFrame || 5]}
                min={3}
                max={8}
                step={1}
                onValueChange={handleLevelsChange}
                className="w-full"
              />
            </div>
          </div>

          <AFrameFarmGrid />

          <div className="mt-4 flex justify-between text-sm">
            <div className="text-green-600">Plants: {modules.length}</div>
            <div className="text-yellow-600">Lighting: {lighting.length} systems</div>
            <div className="text-blue-600">Irrigation: {irrigation.length} pipes</div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function AFrameFarmGrid() {
  const { modules, lighting, farmSize } = useFarm()
  const [selectedPlantForDialog, setSelectedPlantForDialog] = useState<string | null>(null)

  const frames = farmSize.frames || 3
  const levels = farmSize.levelsPerFrame || 5

  // Helper function to get plant at position
  const getPlant = (frame: number, level: number, side: "left" | "right") => {
    return modules.find((m) => m.frame === frame && m.level === level && m.side === side)
  }

  // Helper function to check if frame has lighting
  const hasLighting = (frame: number) => {
    return lighting.some((l) => l.frame === frame)
  }

  const handlePlantClick = (plantId: string) => {
    setSelectedPlantForDialog(plantId)
  }

  const selectedPlant = selectedPlantForDialog ? modules.find((m) => m.id === selectedPlantForDialog) : null

  return (
    <div className="mt-6">
      <div className="grid gap-8" style={{ gridTemplateColumns: `repeat(${Math.min(frames, 3)}, 1fr)` }}>
        {Array.from({ length: frames }, (_, frameIndex) => (
          <div key={frameIndex} className="flex flex-col items-center">
            <div className="text-center mb-4">
              <h3 className="font-semibold text-gray-700">A-Frame {frameIndex + 1}</h3>
              {hasLighting(frameIndex) && (
                <div className="inline-flex items-center gap-1 text-yellow-600 text-xs">
                  <Lightbulb className="w-3 h-3" />
                  {lighting.find((l) => l.frame === frameIndex)?.type || "Lit"}
                </div>
              )}
            </div>

            {/* A-Frame visualization */}
            <div className="relative">
              <svg width="200" height={levels * 40 + 40} className="overflow-visible">
                {/* A-Frame structure */}
                <line
                  x1="100"
                  y1="20"
                  x2="20"
                  y2={levels * 40 + 20}
                  stroke="#8B5CF6"
                  strokeWidth="3"
                  strokeLinecap="round"
                />
                <line
                  x1="100"
                  y1="20"
                  x2="180"
                  y2={levels * 40 + 20}
                  stroke="#8B5CF6"
                  strokeWidth="3"
                  strokeLinecap="round"
                />
                <line
                  x1="20"
                  y1={levels * 40 + 20}
                  x2="180"
                  y2={levels * 40 + 20}
                  stroke="#8B5CF6"
                  strokeWidth="3"
                  strokeLinecap="round"
                />

                {/* Plant positions */}
                {Array.from({ length: levels }, (_, levelIndex) => {
                  const reversedLevel = levels - 1 - levelIndex
                  const y = 40 + levelIndex * 40
                  const leftX = 30 + levelIndex * 15
                  const rightX = 170 - levelIndex * 15

                  const leftPlant = getPlant(frameIndex, reversedLevel, "left")
                  const rightPlant = getPlant(frameIndex, reversedLevel, "right")

                  return (
                    <g key={reversedLevel}>
                      {/* Left side */}
                      <circle
                        cx={leftX}
                        cy={y}
                        r="15"
                        fill={leftPlant ? "#10B981" : "#F3F4F6"}
                        stroke="#059669"
                        strokeWidth="2"
                        strokeDasharray={leftPlant ? "none" : "5,5"}
                        className={leftPlant ? "cursor-pointer hover:fill-green-600" : ""}
                        onClick={() => leftPlant && handlePlantClick(leftPlant.id)}
                        style={{ pointerEvents: leftPlant ? "all" : "none" }}
                      />
                      {leftPlant && (
                        <text
                          x={leftX}
                          y={y + 2}
                          textAnchor="middle"
                          fontSize="8"
                          fill="white"
                          fontWeight="bold"
                          className="pointer-events-none"
                        >
                          {leftPlant.type.slice(0, 3)}
                        </text>
                      )}
                      {!leftPlant && (
                        <text x={leftX} y={y + 2} textAnchor="middle" fontSize="8" fill="#6B7280">
                          L{reversedLevel + 1}
                        </text>
                      )}

                      {/* Right side */}
                      <circle
                        cx={rightX}
                        cy={y}
                        r="15"
                        fill={rightPlant ? "#10B981" : "#F3F4F6"}
                        stroke="#059669"
                        strokeWidth="2"
                        strokeDasharray={rightPlant ? "none" : "5,5"}
                        className={rightPlant ? "cursor-pointer hover:fill-green-600" : ""}
                        onClick={() => rightPlant && handlePlantClick(rightPlant.id)}
                        style={{ pointerEvents: rightPlant ? "all" : "none" }}
                      />
                      {rightPlant && (
                        <text
                          x={rightX}
                          y={y + 2}
                          textAnchor="middle"
                          fontSize="8"
                          fill="white"
                          fontWeight="bold"
                          className="pointer-events-none"
                        >
                          {rightPlant.type.slice(0, 3)}
                        </text>
                      )}
                      {!rightPlant && (
                        <text x={rightX} y={y + 2} textAnchor="middle" fontSize="8" fill="#6B7280">
                          L{reversedLevel + 1}
                        </text>
                      )}

                      {/* Level indicator */}
                      <text x="10" y={y + 2} fontSize="10" fill="#6B7280">
                        {reversedLevel + 1}
                      </text>
                    </g>
                  )
                })}
              </svg>
            </div>
          </div>
        ))}
      </div>

      {/* Dialog for selected plant */}
      {selectedPlant && (
        <PlantModuleCard module={selectedPlant} isOpen={true} onClose={() => setSelectedPlantForDialog(null)} />
      )}
    </div>
  )
}
