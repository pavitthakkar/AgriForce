"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Send, Bot, User, Sprout, AlertCircle, RefreshCw } from "lucide-react"
import { useFarm } from "../contexts/farm-context"
import { useEnvironment } from "../contexts/environment-context"
import { useGrowth } from "../contexts/growth-context"

interface Message {
  id: string
  role: "user" | "assistant" | "error"
  content: string
  timestamp: Date
}

export default function LocalChatSection() {
  const { modules, lighting, irrigation, farmSize, systemType } = useFarm()
  const { currentData, settings } = useEnvironment()
  const { growthData } = useGrowth()

  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        "Hello! I'm your AgriForce AI assistant powered by Groq's LLaMA 3 model. I can help you with questions about your farm setup, plant health, environmental conditions, and provide expert care recommendations. What would you like to know? 🌱",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const scrollAreaRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector("[data-radix-scroll-area-viewport]")
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight
      }
    }
  }, [messages])

  const getFarmContext = () => {
    const plantTypes = [...new Set(modules.map((m) => m.type))]
    const healthStats = modules.reduce(
      (acc, m) => {
        acc[m.health] = (acc[m.health] || 0) + 1
        return acc
      },
      {} as Record<string, number>,
    )

    const recentNotes = modules
      .flatMap((m) => m.notes.map((n) => ({ plant: m.type, note: n.note, date: n.date, health: m.health })))
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 10)

    const unhealthyPlants = modules.filter((m) => m.health === "poor" || m.health === "fair")

    return {
      systemType,
      farmSize,
      totalModules: modules.length,
      plantTypes,
      healthStats,
      recentNotes,
      unhealthyPlants: unhealthyPlants.map((plant) => ({
        type: plant.type,
        health: plant.health,
        location:
          systemType === "tower"
            ? `Tower ${(plant.tower || 0) + 1}, Level ${(plant.level || 0) + 1}`
            : systemType === "a-frame"
              ? `Frame ${(plant.frame || 0) + 1}, ${plant.side} side, Level ${(plant.level || 0) + 1}`
              : `Row ${plant.position.row + 1}, Col ${plant.position.col + 1}`,
        lastNote: plant.notes[plant.notes.length - 1]?.note || "No notes",
      })),
      currentEnvironment: {
        temperature: currentData.temperature,
        targetTemperature: settings.targetTemperature,
        humidity: currentData.humidity,
        targetHumidity: settings.targetHumidity,
        co2Level: currentData.co2Level,
        targetCo2Level: settings.targetCo2Level,
        lightIntensity: currentData.lightIntensity,
        waterPh: currentData.waterPh,
        waterEc: currentData.waterEc,
        outdoorWeather: currentData.outdoorWeather,
      },
      lighting: {
        totalUnits: lighting.length,
        types: [...new Set(lighting.map((l) => l.type))],
        avgIntensity: lighting.length > 0 ? lighting.reduce((sum, l) => sum + l.intensity, 0) / lighting.length : 0,
      },
      irrigation: {
        totalPipes: irrigation.length,
        mainPipes: irrigation.filter((p) => p.type === "main").length,
        branchPipes: irrigation.filter((p) => p.type === "branch").length,
      },
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      const farmContext = getFarmContext()
      console.log("Sending request to /api/chat with model: llama3-8b-8192")

      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: userMessage.content,
          farmContext,
        }),
      })

      console.log("Response status:", response.status)

      let data
      try {
        data = await response.json()
      } catch (parseError) {
        console.error("Error parsing JSON response:", parseError)
        const responseText = await response.text()
        console.error("Raw response:", responseText.substring(0, 500))
        throw new Error(`Failed to parse API response: ${responseText.substring(0, 100)}...`)
      }

      console.log("Response data:", data)

      if (!response.ok) {
        throw new Error(
          `HTTP error! status: ${response.status}, details: ${data.details || data.error || "Unknown error"}`,
        )
      }

      if (data.error) {
        throw new Error(data.details || data.error)
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: data.response,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
      setIsLoading(false)
    } catch (error) {
      console.error("Error calling chat API:", error)

      const farmContext = getFarmContext()
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "error",
        content: `❌ Connection Error: ${error instanceof Error ? error.message : "Unknown error occurred"}

I'm having trouble connecting to the AI service. This could be due to:
• API configuration issues
• Network connectivity problems  
• Service temporarily unavailable

**Local Farm Summary:**
You currently have ${farmContext.totalModules} plants in your ${farmContext.systemType} system. 
Temperature: ${farmContext.currentEnvironment.temperature.toFixed(1)}°C, Humidity: ${farmContext.currentEnvironment.humidity.toFixed(1)}%

You can still use all other features of the farming tool! 🌱`,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, errorMessage])
      setIsLoading(false)
    }
  }

  const handleQuickQuestion = (question: string) => {
    setInput(question)
  }

  const testConnection = async () => {
    try {
      const response = await fetch("/api/test")
      const data = await response.json()
      console.log("API test result:", data)

      const testMessage: Message = {
        id: Date.now().toString(),
        role: "assistant",
        content: `🔧 **Connection Test Results:**
- API Status: ${data.status}
- Environment: ${data.environment}
- Timestamp: ${new Date(data.timestamp).toLocaleTimeString()}

${data.status === "ok" ? "✅ API is working! Try asking a question now." : "❌ API connection failed."}`,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, testMessage])
    } catch (error) {
      console.error("Test connection failed:", error)
    }
  }

  const quickQuestions = [
    "How are my plants doing?",
    "What should I adjust in my environment?",
    "When should I harvest?",
    "Any plants need attention?",
  ]

  return (
    <div className="w-full max-w-4xl mx-auto">
      <Card className="h-[600px] flex flex-col">
        <CardHeader className="pb-4 flex-shrink-0">
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bot className="w-5 h-5 text-green-600" />
              AgriForce AI Assistant
              <span className="text-sm font-normal text-gray-500 ml-2">(Powered by Groq LLaMA 3)</span>
            </div>
            <Button variant="outline" size="sm" onClick={testConnection} title="Test API Connection">
              <RefreshCw className="w-4 h-4" />
            </Button>
          </CardTitle>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col p-0 min-h-0">
          <ScrollArea ref={scrollAreaRef} className="flex-1 px-4">
            <div className="space-y-4 py-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-3 w-full ${message.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`flex gap-3 max-w-[85%] min-w-0 ${
                      message.role === "user" ? "flex-row-reverse" : "flex-row"
                    }`}
                  >
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                        message.role === "user"
                          ? "bg-blue-500 text-white"
                          : message.role === "error"
                            ? "bg-red-500 text-white"
                            : "bg-green-500 text-white"
                      }`}
                    >
                      {message.role === "user" ? (
                        <User className="w-4 h-4" />
                      ) : message.role === "error" ? (
                        <AlertCircle className="w-4 h-4" />
                      ) : (
                        <Sprout className="w-4 h-4" />
                      )}
                    </div>
                    <div
                      className={`rounded-lg p-3 min-w-0 flex-1 ${
                        message.role === "user"
                          ? "bg-blue-500 text-white"
                          : message.role === "error"
                            ? "bg-red-50 text-red-900 border border-red-200"
                            : "bg-gray-100 text-gray-900 border"
                      }`}
                    >
                      <div className="text-sm whitespace-pre-wrap break-words overflow-wrap-anywhere">
                        {message.content}
                      </div>
                      <div
                        className={`text-xs mt-1 opacity-70 ${
                          message.role === "user"
                            ? "text-blue-100"
                            : message.role === "error"
                              ? "text-red-600"
                              : "text-gray-500"
                        }`}
                      >
                        {message.timestamp.toLocaleTimeString()}
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex gap-3 justify-start w-full">
                  <div className="w-8 h-8 rounded-full bg-green-500 text-white flex items-center justify-center flex-shrink-0">
                    <Sprout className="w-4 h-4" />
                  </div>
                  <div className="bg-gray-100 border rounded-lg p-3 min-w-0 flex-1 max-w-[85%]">
                    <div className="text-sm text-gray-600 flex items-center gap-2">
                      <div className="animate-pulse">AI is thinking...</div>
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.1s" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </ScrollArea>

          <div className="border-t bg-white p-4 flex-shrink-0">
            {/* Quick question buttons */}
            <div className="mb-3">
              <div className="text-xs text-gray-500 mb-2">Quick questions:</div>
              <div className="flex flex-wrap gap-2">
                {quickQuestions.map((question, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    onClick={() => handleQuickQuestion(question)}
                    disabled={isLoading}
                    className="text-xs"
                  >
                    {question}
                  </Button>
                ))}
              </div>
            </div>

            <form onSubmit={handleSubmit} className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about plant care, environmental conditions, harvest timing, or any farming questions..."
                disabled={isLoading}
                className="flex-1 min-w-0"
                autoComplete="off"
              />
              <Button
                type="submit"
                disabled={isLoading || !input.trim()}
                className="bg-green-600 hover:bg-green-700 px-4 flex-shrink-0"
              >
                <Send className="w-4 h-4" />
              </Button>
            </form>
            <div className="text-xs text-gray-500 mt-2">
              Powered by Groq LLaMA 3 - Ask about plant care, environmental optimization, harvest timing, or any farming
              questions!
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
