import LoginForm from "@/app/components/auth/login-form"

export default function LoginPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 flex flex-col items-center justify-center p-4">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-green-800 mb-2">AgriForce</h1>
        <p className="text-green-600">Sign in to your account</p>
      </div>
      <LoginForm />
    </div>
  )
}
