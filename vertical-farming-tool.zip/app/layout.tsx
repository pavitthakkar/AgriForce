import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { AuthProvider } from "./contexts/auth-context"
import { FarmProvider } from "./contexts/farm-context"
import { EnvironmentProvider } from "./contexts/environment-context"
import { GrowthProvider } from "./contexts/growth-context"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "AgriForce - Vertical Farming Platform",
  description: "Advanced vertical farming management and optimization platform",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <AuthProvider>
            <FarmProvider>
              <EnvironmentProvider>
                <GrowthProvider>
                  {children}
                  <Toaster />
                </GrowthProvider>
              </EnvironmentProvider>
            </FarmProvider>
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
